# Golden Visa UAE - Premium Consultancy Website

A production-ready, premium website for a UAE Golden Visa and residency consultancy, built with React, TypeScript, Tailwind CSS, and Framer Motion.

## 🎨 Design Features

- **Premium Visual Identity**: Sophisticated navy, gold, and ivory color palette
- **Smooth Animations**: Framer Motion-powered transitions and scroll effects
- **Real Photography**: High-quality Unsplash images throughout
- **Responsive Design**: Optimized for all devices (mobile, tablet, desktop)
- **Accessibility**: WCAG-compliant with proper ARIA labels and keyboard navigation
- **Performance**: Optimized images, lazy loading, and efficient code splitting

## 🚀 Technology Stack

- **React 18** - Modern UI library
- **TypeScript** - Type-safe development
- **Tailwind CSS 4** - Utility-first styling
- **Framer Motion** - Smooth animations
- **React Router** - Client-side routing
- **Lucide React** - Premium icon set
- **Vite** - Fast build tool

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Header.tsx      # Navigation with mobile menu
│   ├── Footer.tsx      # Multi-column footer
│   ├── WhatsAppButton.tsx  # Floating WhatsApp CTA
│   ├── ConsultationForm.tsx # Contact form with validation
│   ├── PageComponents.tsx   # Shared page components
│   ├── UXComponents.tsx     # Back-to-top, mobile CTA
│   ├── WhatsAppIcon.tsx     # Real WhatsApp SVG icon
│   ├── ScrollProgress.tsx   # Scroll progress indicator
│   └── CookieBanner.tsx     # Cookie consent banner
├── pages/              # Page components
│   ├── Home.tsx        # Homepage with all sections
│   ├── GoldenVisa.tsx  # Golden Visa details
│   ├── ServicePages.tsx # All service pages
│   ├── BusinessSetup.tsx
│   ├── About.tsx
│   ├── Process.tsx
│   ├── FAQ.tsx
│   ├── Contact.tsx
│   ├── PrivacyPolicy.tsx
│   ├── Terms.tsx
│   └── NotFound.tsx    # 404 page
├── config.ts           # Central configuration
├── data.ts            # Services, FAQs, testimonials
├── images.ts          # Image URLs
├── animations.ts      # Animation presets
├── App.tsx            # Main app with routing
├── main.tsx           # Entry point
└── index.css          # Global styles
```

## 🎯 Key Pages

- **Home** - Hero, services, process, testimonials, blog, FAQ
- **Golden Visa** - Detailed programme information
- **Residency Options** - Overview of all pathways
- **Service Pages** - Individual visa types (Investor, Property, Entrepreneur, Professional, Family)
- **Business Setup** - UAE company formation guidance
- **About** - Company information and approach
- **Process** - Step-by-step consultation process
- **FAQ** - Accordion-style frequently asked questions
- **Contact** - Consultation form with validation
- **Legal** - Privacy Policy and Terms & Conditions

## ⚙️ Configuration

All business information is centralized in `src/config.ts`:

```typescript
export const config = {
  business: {
    name: 'Golden Visa UAE',
    tagline: 'UAE Residency & Investment Consultancy',
    // ...
  },
  contact: {
    email: 'info@goldenvisauae.net',
    phone: '+971 XX XXX XXXX',
    whatsapp: '+971XXXXXXXXX',
    whatsappLink: 'https://wa.me/971XXXXXXXXX',
    address: { /* ... */ },
    hours: { /* ... */ },
  },
  // ...
};
```

**To update client information:**
1. Edit `src/config.ts`
2. Update WhatsApp number in both `whatsapp` and `whatsappLink`
3. Update email, phone, and address
4. Rebuild the project

## 🖼️ Images

All images are sourced from Unsplash (free to use). Image URLs are centralized in `src/images.ts`:

- Hero: Dubai skyline
- Service pages: Relevant professional imagery
- Blog posts: Category-specific images
- 404 page: Dubai architecture

**To replace images:**
Edit `src/images.ts` with new Unsplash URLs or your own images.

## 🎨 Brand Colors

```css
--color-navy: #07111F        /* Primary dark */
--color-navy-light: #0D1B2A  /* Secondary dark */
--color-gold: #C9A45C        /* Accent gold */
--color-gold-light: #E7D3A3  /* Light gold */
--color-ivory: #F7F5F0       /* Background */
--color-gray-muted: #687386  /* Text secondary */
```

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1023px
- Desktop: ≥ 1024px
- Large: ≥ 1280px

## 🚀 Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📦 Production Build

The build output is in the `dist/` directory:
- `dist/index.html` - Main HTML file
- `dist/assets/` - CSS and JS bundles
- Optimized and minified for production

## 🔍 SEO Features

- Semantic HTML5 structure
- Meta tags for all pages
- Open Graph tags
- Twitter Card tags
- JSON-LD structured data (Organization, WebSite, FAQPage)
- Proper heading hierarchy (H1-H6)
- Alt text for all images
- Canonical URLs

## ♿ Accessibility

- ARIA labels and roles
- Keyboard navigation
- Focus indicators
- Screen reader friendly
- Reduced motion support
- Color contrast compliance
- Form validation with error messages

## 🎭 Animations

Smooth, premium animations using Framer Motion:
- Fade-in on scroll
- Staggered list animations
- Smooth page transitions
- Hover effects on cards and buttons
- Mobile menu slide-in
- Accordion open/close

All animations respect `prefers-reduced-motion`.

## 📊 Analytics Ready

The site is prepared for analytics integration:
- Google Analytics (add ID in config)
- Google Tag Manager (add ID in config)
- Meta Pixel (add ID in config)

Event tracking points are in place for:
- Form submissions
- WhatsApp clicks
- Consultation CTA clicks
- Phone/email clicks

## 🔒 Security Features

- No hardcoded secrets
- Environment variables for sensitive data
- Input sanitization
- Form validation
- Honeypot field for spam protection
- Secure headers in HTML
- HTTPS-ready architecture

## 📝 Content Guidelines

The website uses careful, legally-compliant language:
- No guarantees of visa approval
- Clear disclaimers about eligibility
- References to "applicable UAE regulations"
- Distinction from government authorities
- Professional, trustworthy tone

## 🎯 Conversion Optimization

- Multiple CTAs throughout the site
- Floating WhatsApp button
- Mobile sticky CTA bar
- Consultation form with validation
- Trust indicators and testimonials
- Clear process explanation
- FAQ section to address concerns

## 🌐 Browser Support

- Chrome/Edge (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📄 License

This is a custom-built website for Golden Visa UAE. All rights reserved.

## 🤝 Support

For questions or modifications, contact the development team.

---

**Built with precision and care for a premium UAE consultancy experience.**
