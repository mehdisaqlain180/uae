import { useState, type FormEvent } from 'react';
import { CheckCircle, AlertCircle } from 'lucide-react';

interface FormData {
  fullName: string;
  email: string;
  phone: string;
  country: string;
  interestedIn: string;
  investmentRange: string;
  message: string;
}

const initialData: FormData = {
  fullName: '',
  email: '',
  phone: '',
  country: '',
  interestedIn: '',
  investmentRange: '',
  message: '',
};

const interestedOptions = [
  'Golden Visa',
  'Property Investor Residency',
  'Entrepreneur Residency',
  'Skilled Professional Residency',
  'Family Residency',
  'Business Setup',
  'Not Sure Yet',
];

export default function ConsultationForm({ compact = false }: { compact?: boolean }) {
  const [formData, setFormData] = useState<FormData>(initialData);
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const validate = (): boolean => {
    const newErrors: Partial<FormData> = {};
    if (!formData.fullName.trim()) newErrors.fullName = 'Please enter your name';
    if (!formData.email.trim()) newErrors.email = 'Please enter your email';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Please enter a valid email';
    if (!formData.phone.trim()) newErrors.phone = 'Please enter your phone number';
    else if (formData.phone.replace(/\D/g, '').length < 7) newErrors.phone = 'Please enter a valid phone number';
    if (!formData.country.trim()) newErrors.country = 'Please enter your country';
    if (!formData.interestedIn) newErrors.interestedIn = 'Please select an option';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setStatus('loading');
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setStatus('success');
    setFormData(initialData);
  };

  const handleChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: undefined }));
  };

  if (status === 'success') {
    return (
      <div className="text-center py-10 px-6">
        <CheckCircle className="mx-auto text-green-600 mb-4" size={48} />
        <h3 className="font-heading font-semibold text-xl text-navy mb-2">Thank you</h3>
        <p className="text-gray-muted text-sm max-w-sm mx-auto">
          Your enquiry has been received. Our team will be in touch shortly to discuss your requirements.
        </p>
        <button
          onClick={() => setStatus('idle')}
          className="mt-6 text-sm font-medium text-gold hover:text-navy transition-colors"
        >
          Submit another enquiry
        </button>
      </div>
    );
  }

  const inputClass = (field: keyof FormData) =>
    `w-full px-4 py-3 bg-white border rounded text-sm text-navy placeholder:text-gray-muted/60 transition-colors ${
      errors[field] ? 'border-red-400' : 'border-gray-200 focus:border-gold'
    }`;

  return (
    <form onSubmit={handleSubmit} noValidate className={compact ? '' : 'space-y-5'}>
      <div className={compact ? 'grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4' : 'space-y-5'}>
        <div>
          <label htmlFor="fullName" className="block text-sm font-medium text-navy mb-1.5">Full Name *</label>
          <input
            id="fullName"
            type="text"
            value={formData.fullName}
            onChange={(e) => handleChange('fullName', e.target.value)}
            className={inputClass('fullName')}
            placeholder="Your full name"
            required
          />
          {errors.fullName && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><AlertCircle size={12} />{errors.fullName}</p>}
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-navy mb-1.5">Email *</label>
          <input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => handleChange('email', e.target.value)}
            className={inputClass('email')}
            placeholder="your@email.com"
            required
          />
          {errors.email && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><AlertCircle size={12} />{errors.email}</p>}
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-navy mb-1.5">Phone / WhatsApp *</label>
          <input
            id="phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            className={inputClass('phone')}
            placeholder="+971 XX XXX XXXX"
            required
          />
          {errors.phone && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><AlertCircle size={12} />{errors.phone}</p>}
        </div>

        <div>
          <label htmlFor="country" className="block text-sm font-medium text-navy mb-1.5">Country of Residence *</label>
          <input
            id="country"
            type="text"
            value={formData.country}
            onChange={(e) => handleChange('country', e.target.value)}
            className={inputClass('country')}
            placeholder="Your country"
            required
          />
          {errors.country && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><AlertCircle size={12} />{errors.country}</p>}
        </div>

        <div>
          <label htmlFor="interestedIn" className="block text-sm font-medium text-navy mb-1.5">Interested In *</label>
          <select
            id="interestedIn"
            value={formData.interestedIn}
            onChange={(e) => handleChange('interestedIn', e.target.value)}
            className={inputClass('interestedIn')}
            required
          >
            <option value="">Select an option</option>
            {interestedOptions.map(opt => (
              <option key={opt} value={opt}>{opt}</option>
            ))}
          </select>
          {errors.interestedIn && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><AlertCircle size={12} />{errors.interestedIn}</p>}
        </div>

        <div>
          <label htmlFor="investmentRange" className="block text-sm font-medium text-navy mb-1.5">Investment Range <span className="text-gray-muted">(optional)</span></label>
          <select
            id="investmentRange"
            value={formData.investmentRange}
            onChange={(e) => handleChange('investmentRange', e.target.value)}
            className={inputClass('investmentRange')}
          >
            <option value="">Prefer not to say</option>
            <option value="under-1m">Under AED 1M</option>
            <option value="1m-2m">AED 1M – 2M</option>
            <option value="2m-5m">AED 2M – 5M</option>
            <option value="5m-10m">AED 5M – 10M</option>
            <option value="over-10m">Over AED 10M</option>
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="message" className="block text-sm font-medium text-navy mb-1.5">Message <span className="text-gray-muted">(optional)</span></label>
        <textarea
          id="message"
          value={formData.message}
          onChange={(e) => handleChange('message', e.target.value)}
          className={`${inputClass('message')} min-h-[100px] resize-y`}
          placeholder="Tell us briefly about your requirements..."
          rows={4}
        />
      </div>

      {/* Honeypot */}
      <div className="hidden" aria-hidden="true">
        <input type="text" name="website" tabIndex={-1} autoComplete="off" />
      </div>

      <button
        type="submit"
        disabled={status === 'loading'}
        className="btn-primary w-full bg-gold text-navy px-6 py-3.5 rounded font-semibold text-sm disabled:opacity-60 flex items-center justify-center gap-2"
      >
        {status === 'loading' ? (
          <>
            <span className="spinner" />
            Sending...
          </>
        ) : (
          'Request a Consultation'
        )}
      </button>

      <p className="text-xs text-gray-muted text-center mt-3">
        By submitting this form, you agree that we may contact you regarding your enquiry.
      </p>

      {status === 'error' && (
        <p className="text-sm text-red-500 text-center mt-2 flex items-center justify-center gap-1">
          <AlertCircle size={14} />
          Something went wrong. Please try again or contact us directly.
        </p>
      )}
    </form>
  );
}
