import { Link } from 'react-router-dom';
import { MessageCircle, Mail, MapPin } from 'lucide-react';
import { config } from '../config';

export default function Footer() {
  return (
    <footer className="bg-navy text-white/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12">
          {/* Column 1: Brand */}
          <div className="lg:col-span-1">
            <Link to="/" className="inline-block mb-4">
              <span className="font-heading font-bold text-xl text-white">
                <span className="text-gold">GOLDEN</span> VISA
              </span>
              <span className="font-heading font-medium text-sm text-white/60 ml-1">UAE</span>
            </Link>
            <p className="text-sm leading-relaxed text-white/60 max-w-xs">
              {config.business.description} Private consultations for international investors, professionals and families.
            </p>
          </div>

          {/* Column 2: Services */}
          <div>
            <h3 className="font-heading font-semibold text-white text-sm uppercase tracking-wider mb-4">Services</h3>
            <ul className="space-y-2.5">
              {[
                { label: 'Golden Visa', path: '/golden-visa' },
                { label: 'Investor Residency', path: '/investor-visa' },
                { label: 'Property Investor', path: '/property-investor' },
                { label: 'Entrepreneur', path: '/entrepreneur-visa' },
                { label: 'Skilled Professional', path: '/skilled-professional' },
                { label: 'Family Residency', path: '/family-residency' },
              ].map((item) => (
                <li key={item.path}>
                  <Link to={item.path} className="text-sm text-white/60 hover:text-gold transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Company */}
          <div>
            <h3 className="font-heading font-semibold text-white text-sm uppercase tracking-wider mb-4">Company</h3>
            <ul className="space-y-2.5">
              {[
                { label: 'About', path: '/about' },
                { label: 'Process', path: '/process' },
                { label: 'FAQ', path: '/faq' },
                { label: 'Contact', path: '/contact' },
                { label: 'Business Setup', path: '/business-setup' },
              ].map((item) => (
                <li key={item.path}>
                  <Link to={item.path} className="text-sm text-white/60 hover:text-gold transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Contact */}
          <div>
            <h3 className="font-heading font-semibold text-white text-sm uppercase tracking-wider mb-4">Contact</h3>
            <ul className="space-y-3">
              <li>
                <a href={`mailto:${config.contact.email}`} className="flex items-center gap-2 text-sm text-white/60 hover:text-gold transition-colors">
                  <Mail size={14} className="text-gold shrink-0" />
                  {config.contact.email}
                </a>
              </li>
              <li>
                <a href={config.contact.whatsappLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-white/60 hover:text-gold transition-colors">
                  <MessageCircle size={14} className="text-gold shrink-0" />
                  WhatsApp
                </a>
              </li>
              <li>
                <span className="flex items-start gap-2 text-sm text-white/60">
                  <MapPin size={14} className="text-gold shrink-0 mt-0.5" />
                  <span>{config.contact.address.line1}<br />{config.contact.address.line2}</span>
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-14 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/40">
            © {config.legal.year} {config.legal.companyName}. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/privacy-policy" className="text-xs text-white/40 hover:text-white/70 transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-xs text-white/40 hover:text-white/70 transition-colors">
              Terms & Conditions
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
