import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { config } from '../config';
import { navigation } from '../data';
import WhatsAppIcon from './WhatsAppIcon';

export default function Header() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    if (isMobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isMobileOpen]);

  useEffect(() => {
    setIsMobileOpen(false);
  }, [location]);

  // Close menu on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMobileOpen(false);
      }
    };
    if (isMobileOpen) {
      document.addEventListener('keydown', handleEscape);
    }
    return () => { document.removeEventListener('keydown', handleEscape); };
  }, [isMobileOpen]);

  // Social proof ticker data
  const tickerItems = [
    { name: 'Ahmed Al-Maktoum', action: 'secured Golden Visa', time: '2 hours ago' },
    { name: 'Sarah Johnson', action: 'secured Property Investor Visa', time: '5 hours ago' },
    { name: 'Rajesh Patel', action: 'secured Entrepreneur Visa', time: '8 hours ago' },
    { name: 'Maria Garcia', action: 'secured Skilled Professional Visa', time: '12 hours ago' },
    { name: 'Chen Wei', action: 'secured Golden Visa', time: '1 day ago' },
    { name: 'Fatima Hassan', action: 'secured Family Residency', time: '1 day ago' },
  ];

  return (
    <>
      {/* Ticker Bar */}
      <div className="absolute top-0 left-0 right-0 z-[60] bg-black py-1.5 overflow-hidden border-b border-white/5">
        <div className="ticker-animation flex items-center whitespace-nowrap">
          {[...tickerItems, ...tickerItems].map((item, index) => (
            <div key={index} className="flex items-center gap-2 text-xs px-6">
              <span className="text-gold font-semibold">{item.name}</span>
              <span className="text-white/80">{item.action}</span>
              <span className="text-white/40">• {item.time}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Bar */}
      <motion.header
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
        className="absolute top-12 left-0 right-0 z-50 px-4"
      >
        <div className="max-w-7xl mx-auto">
          <div className="bg-[#1e2126]/95 backdrop-blur-md rounded-xl shadow-xl border border-white/10">
            <div className="flex items-center justify-between px-10 py-4">
              {/* Logo with Golden Wing */}
              <Link to="/" className="flex items-center gap-3 group" aria-label="Golden Visa UAE - Home">
                <div className="relative">
                  <div className="absolute inset-0 bg-gold/20 rounded-full blur-md group-hover:bg-gold/30 transition-all duration-300" />
                  <svg width="36" height="36" viewBox="0 0 32 32" className="text-gold relative z-10">
                    <path fill="currentColor" d="M16 4 L8 12 L12 12 L12 20 L8 20 L16 28 L24 20 L20 20 L20 12 L24 12 Z" />
                  </svg>
                </div>
                <div className="font-heading text-lg">
                  <span className="text-white font-semibold">Golden Visa</span>
                  <span className="text-gold font-bold ml-1.5">UAE</span>
                </div>
              </Link>

              {/* Desktop Navigation */}
              <nav className="hidden lg:flex items-center gap-10" aria-label="Main navigation">
                {navigation.main.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`relative text-base font-medium transition-all duration-300 group whitespace-nowrap py-2 ${
                      location.pathname === item.path
                        ? 'text-gold'
                        : 'text-white/90 hover:text-gold'
                    }`}
                  >
                    {item.label}
                    <span className={`absolute bottom-0 left-0 w-full h-0.5 bg-gold transform origin-left transition-transform duration-300 ${
                      location.pathname === item.path ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
                    }`} />
                  </Link>
                ))}
              </nav>

              {/* CTA Button */}
              <div className="hidden lg:flex items-center">
                <Link
                  to="/contact"
                  className="group relative flex items-center gap-2.5 bg-gradient-to-r from-gold to-gold-light text-navy px-6 py-3 rounded-full text-base font-bold hover:shadow-lg hover:shadow-gold/50 transition-all duration-300 hover:scale-105"
                >
                  <Phone size={18} className="group-hover:rotate-12 transition-transform duration-300" />
                  <span>Book Consultation</span>
                </Link>
              </div>

              {/* Mobile Menu Button */}
              {!isMobileOpen && (
                <button
                  type="button"
                  className="lg:hidden p-2 relative z-[51] min-w-[44px] min-h-[44px] flex items-center justify-center"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setIsMobileOpen(true);
                  }}
                  aria-label="Open menu"
                >
                  <Menu className="text-white" size={24} strokeWidth={2} />
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 z-[60] bg-navy overflow-y-auto"
            role="dialog"
            aria-modal="true"
            aria-label="Mobile navigation"
          >
            <div className="flex items-center justify-between p-5 border-b border-white/10 sticky top-0 bg-navy z-10">
              <Link 
                to="/" 
                onClick={() => setIsMobileOpen(false)}
                className="flex items-center gap-3"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-gold/20 rounded-full blur-md" />
                  <svg width="32" height="32" viewBox="0 0 32 32" className="text-gold relative z-10">
                    <path fill="currentColor" d="M16 4 L8 12 L12 12 L12 20 L8 20 L16 28 L24 20 L20 20 L20 12 L24 12 Z" />
                  </svg>
                </div>
                <div className="font-heading text-xl">
                  <span className="text-white font-semibold">Golden Visa</span>
                  <span className="text-gold font-bold ml-1.5">UAE</span>
                </div>
              </Link>
              <button
                type="button"
                onClick={() => setIsMobileOpen(false)}
                className="p-3 text-white hover:bg-white/10 rounded-lg transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
                aria-label="Close menu"
              >
                <X size={28} strokeWidth={2} />
              </button>
            </div>
            <nav className="flex flex-col p-8 gap-2" aria-label="Mobile navigation">
              {navigation.main.map((item, index) => (
                <motion.div
                  key={item.path}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                >
                  <Link
                    to={item.path}
                    onClick={() => setIsMobileOpen(false)}
                    className={`py-5 px-5 text-xl font-semibold rounded-xl transition-all block min-h-[56px] flex items-center border-l-4 ${
                      location.pathname === item.path
                        ? 'text-gold bg-white/5 border-gold'
                        : 'text-white/80 hover:text-white hover:bg-white/5 border-transparent hover:border-gold/50'
                    }`}
                  >
                    {item.label}
                  </Link>
                </motion.div>
              ))}
              <motion.div 
                className="mt-8 pt-8 border-t border-white/10 flex flex-col gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.3 }}
              >
                <Link
                  to="/contact"
                  onClick={() => setIsMobileOpen(false)}
                  className="bg-gradient-to-r from-gold to-gold-light text-navy px-6 py-4 rounded-full text-center font-bold text-lg min-h-[56px] flex items-center justify-center shadow-lg shadow-gold/20"
                >
                  Book a Consultation
                </Link>
                <a
                  href={config.contact.whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-3 border-2 border-white/20 text-white px-6 py-4 rounded-full text-lg font-semibold min-h-[56px] hover:border-gold hover:text-gold transition-all"
                >
                  <WhatsAppIcon size={20} />
                  Chat on WhatsApp
                </a>
              </motion.div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
