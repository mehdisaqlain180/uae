import { ReactNode } from 'react';
import { 
  Building, TrendingUp, Lightbulb, Briefcase, GraduationCap, Award,
  Users, Globe, Check, Shield, Lock, ArrowRight, Phone, Mail, MapPin,
  Star, ChevronDown, ChevronUp, Menu, X, MessageCircle, Clock,
  type LucideIcon
} from 'lucide-react';

interface EnhancedIconProps {
  icon: LucideIcon;
  size?: number;
  variant?: 'gold' | 'navy' | 'gradient' | 'outline';
  className?: string;
  animated?: boolean;
}

export function EnhancedIcon({ 
  icon: Icon, 
  size = 24, 
  variant = 'gold',
  className = '',
  animated = false 
}: EnhancedIconProps) {
  const baseClasses = 'inline-flex items-center justify-center transition-all duration-500';
  
  const variantClasses = {
    gold: 'bg-gradient-to-br from-gold/20 to-gold/5 text-gold',
    navy: 'bg-gradient-to-br from-navy/20 to-navy/5 text-navy',
    gradient: 'bg-gradient-to-br from-gold via-gold-light to-gold text-navy',
    outline: 'border-2 border-gold text-gold bg-transparent',
  };

  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-14 h-14',
    lg: 'w-16 h-16',
    xl: 'w-20 h-20',
  };

  const iconSizes = {
    sm: 18,
    md: 24,
    lg: 28,
    xl: 32,
  };

  const containerSize = size <= 18 ? 'sm' : size <= 24 ? 'md' : size <= 28 ? 'lg' : 'xl';

  return (
    <div className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[containerSize]} rounded-xl shadow-lg ${animated ? 'hover:scale-110 hover:rotate-3' : ''} ${className}`}>
      <Icon size={iconSizes[containerSize]} strokeWidth={1.5} />
    </div>
  );
}

// Premium icon with glow effect
export function GlowIcon({ 
  icon: Icon, 
  size = 32, 
  color = 'gold',
  className = '' 
}: { 
  icon: LucideIcon; 
  size?: number; 
  color?: 'gold' | 'navy';
  className?: string;
}) {
  const colorClasses = {
    gold: {
      bg: 'bg-gold/10',
      text: 'text-gold',
      glow: 'bg-gold/30',
    },
    navy: {
      bg: 'bg-navy/10',
      text: 'text-navy',
      glow: 'bg-navy/30',
    },
  };

  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      {/* Glow effect */}
      <div className={`absolute inset-0 ${colorClasses[color].glow} rounded-full blur-xl opacity-50`} />
      {/* Icon container */}
      <div className={`relative w-16 h-16 rounded-2xl ${colorClasses[color].bg} flex items-center justify-center ${colorClasses[color].text} shadow-lg`}>
        <Icon size={size} strokeWidth={1.5} />
      </div>
    </div>
  );
}

// Gradient icon with border
export function GradientBorderIcon({ 
  icon: Icon, 
  size = 28,
  className = ''
}: { 
  icon: LucideIcon; 
  size?: number;
  className?: string;
}) {
  return (
    <div className={`relative inline-flex items-center justify-center p-[2px] rounded-xl bg-gradient-to-br from-gold via-gold-light to-gold ${className}`}>
      <div className="w-14 h-14 rounded-[10px] bg-white flex items-center justify-center text-gold">
        <Icon size={size} strokeWidth={1.5} />
      </div>
    </div>
  );
}

// Icon with decorative corner
export function DecoratedIcon({ 
  icon: Icon, 
  size = 24,
  className = ''
}: { 
  icon: LucideIcon; 
  size?: number;
  className?: string;
}) {
  return (
    <div className={`relative inline-flex ${className}`}>
      {/* Corner decoration */}
      <div className="absolute -top-1 -right-1 w-4 h-4">
        <div className="absolute top-0 right-0 w-px h-3 bg-gradient-to-b from-gold to-transparent" />
        <div className="absolute top-0 right-0 h-px w-3 bg-gradient-to-l from-gold to-transparent" />
      </div>
      {/* Main icon */}
      <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-gold/10 to-gold/5 flex items-center justify-center text-gold shadow-md">
        <Icon size={size} strokeWidth={1.5} />
      </div>
    </div>
  );
}

// Service icons mapping with enhanced styling
export const serviceIcons = {
  building: <EnhancedIcon icon={Building} variant="gold" animated />,
  'trending-up': <EnhancedIcon icon={TrendingUp} variant="gradient" animated />,
  lightbulb: <EnhancedIcon icon={Lightbulb} variant="gold" animated />,
  briefcase: <EnhancedIcon icon={Briefcase} variant="gradient" animated />,
  'graduation-cap': <EnhancedIcon icon={GraduationCap} variant="gold" animated />,
  award: <EnhancedIcon icon={Award} variant="gradient" animated />,
};

// Statistics icons with glow
export const statIcons = {
  users: <GlowIcon icon={Users} color="gold" />,
  award: <GlowIcon icon={Award} color="gold" />,
  check: <GlowIcon icon={Check} color="gold" />,
  globe: <GlowIcon icon={Globe} color="gold" />,
};

// Trust icons
export const trustIcons = {
  shield: <GradientBorderIcon icon={Shield} />,
  users: <GradientBorderIcon icon={Users} />,
  lock: <GradientBorderIcon icon={Lock} />,
  globe: <GradientBorderIcon icon={Globe} />,
};

// Contact icons
export const contactIcons = {
  phone: <DecoratedIcon icon={Phone} />,
  mail: <DecoratedIcon icon={Mail} />,
  mapPin: <DecoratedIcon icon={MapPin} />,
  clock: <DecoratedIcon icon={Clock} />,
};

// Export all icons for easy access
export {
  Building, TrendingUp, Lightbulb, Briefcase, GraduationCap, Award,
  Users, Globe, Check, Shield, Lock, ArrowRight, Phone, Mail, MapPin,
  Star, ChevronDown, ChevronUp, Menu, X, MessageCircle, Clock
};
