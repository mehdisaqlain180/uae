import { config } from '../config';
import WhatsAppIcon from './WhatsAppIcon';
import { useLocation } from 'react-router-dom';

export default function WhatsAppButton() {
  const location = useLocation();

  // Hide on home page
  if (location.pathname === '/') return null;

  return (
    <a
      href={config.contact.whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="whatsapp-float fixed bottom-6 right-6 z-40 bg-[#25D366] text-white p-3.5 rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center justify-center"
      aria-label="Chat on WhatsApp"
    >
      <WhatsAppIcon size={24} />
    </a>
  );
}
