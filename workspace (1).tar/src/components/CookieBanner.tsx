import { useState, useEffect } from 'react';

export default function CookieBanner() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem('cookie-consent');
    if (!accepted) {
      const timer = setTimeout(() => setShow(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookie-consent', 'accepted');
    setShow(false);
  };

  const handleManage = () => {
    localStorage.setItem('cookie-consent', 'essential-only');
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="cookie-banner fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg p-4 sm:p-6">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <p className="text-sm text-gray-muted leading-relaxed max-w-2xl">
          We use cookies to improve your experience on our website. Essential cookies are required for the site to function. You can manage your preferences or accept all cookies.
        </p>
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleManage}
            className="text-sm font-medium text-gray-muted hover:text-navy transition-colors px-4 py-2"
          >
            Manage Preferences
          </button>
          <button
            onClick={handleAccept}
            className="bg-navy text-white text-sm font-medium px-5 py-2.5 rounded hover:bg-navy-light transition-colors"
          >
            Accept
          </button>
        </div>
      </div>
    </div>
  );
}
