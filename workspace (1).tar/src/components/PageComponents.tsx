import { Link } from 'react-router-dom';
import { Check, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { config } from '../config';
import { images } from '../images';
import WhatsAppIcon from './WhatsAppIcon';

interface PageHeroProps {
  eyebrow: string;
  title: string;
  subtitle?: string;
}

export function PageHero({ eyebrow, title, subtitle }: PageHeroProps) {
  return (
    <section className="relative pt-32 pb-16 lg:pt-40 lg:pb-20 bg-navy overflow-hidden">
      <motion.div 
        className="absolute inset-0 w-full h-full opacity-20"
        initial={{ scale: 1.1 }}
        animate={{ scale: 1 }}
        transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
      >
        <img
          src={images.hero}
          alt=""
          className="absolute inset-0 w-full h-full object-cover object-center"
          loading="eager"
        />
        <div className="absolute inset-0 bg-navy/80" />
      </motion.div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.p 
          className="text-gold text-xs font-medium uppercase tracking-[0.2em] mb-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {eyebrow}
        </motion.p>
        <motion.h1 
          className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl text-white leading-tight mb-4"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
        >
          {title}
        </motion.h1>
        {subtitle && (
          <motion.p 
            className="text-white/60 text-base sm:text-lg max-w-2xl leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {subtitle}
          </motion.p>
        )}
      </div>
    </section>
  );
}

interface BreadcrumbProps {
  items: { label: string; path?: string }[];
}

export function Breadcrumbs({ items }: BreadcrumbProps) {
  return (
    <nav aria-label="Breadcrumb" className="bg-ivory border-b border-gray-200/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <ol className="flex items-center gap-2 text-xs text-gray-muted">
          <li>
            <Link to="/" className="hover:text-navy transition-colors">Home</Link>
          </li>
          {items.map((item, i) => (
            <li key={i} className="flex items-center gap-2">
              <span>/</span>
              {item.path ? (
                <Link to={item.path} className="hover:text-navy transition-colors">{item.label}</Link>
              ) : (
                <span className="text-navy font-medium">{item.label}</span>
              )}
            </li>
          ))}
        </ol>
      </div>
    </nav>
  );
}

export function CTASection() {
  return (
    <section className="py-20 lg:py-24 bg-navy relative overflow-hidden">
      <div className="absolute inset-0 w-full h-full opacity-10">
        <img src={images.dubai2} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
      </div>
      <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="font-heading font-bold text-2xl sm:text-3xl text-white mb-4">
            Ready to discuss your options?
          </h2>
          <p className="text-white/60 mb-8">
            Our team is available to review your circumstances and help identify the most relevant pathway.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link to="/contact" className="btn-primary bg-gold text-navy px-7 py-3.5 rounded font-semibold text-sm group">
              <span className="inline-flex items-center gap-2">
                Book a Consultation
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </span>
            </Link>
            <a
              href={config.contact.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 border border-white/20 text-white px-7 py-3.5 rounded font-medium text-sm hover:bg-white/10 transition-all duration-300"
            >
              <WhatsAppIcon size={16} />
              Chat on WhatsApp
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function FeatureList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-3">
      {items.map((item, index) => (
        <motion.li 
          key={item} 
          className="flex items-start gap-3 text-sm text-navy"
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <Check size={16} className="text-gold shrink-0 mt-0.5" />
          <span>{item}</span>
        </motion.li>
      ))}
    </ul>
  );
}

export function Disclaimer() {
  return (
    <motion.p 
      className="text-xs text-gray-muted mt-6 p-4 bg-ivory rounded border border-gray-100"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
    >
      <strong>Important:</strong> Eligibility requirements and regulations are set by the relevant UAE authorities and may change. Final decisions on residency applications are made by the appropriate government bodies. This website provides general guidance only and does not constitute legal advice.
    </motion.p>
  );
}

export function ServicePageTemplate({
  title,
  description,
  features,
  additionalInfo,
  image,
}: {
  title: string;
  description: string;
  features: string[];
  additionalInfo?: string;
  image?: string;
}) {
  return (
    <main>
      <PageHero
        eyebrow="Residency Pathway"
        title={title}
        subtitle={description}
      />
      <Breadcrumbs items={[{ label: title }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <div className="gold-line mb-4" />
              <h2 className="font-heading font-bold text-2xl text-navy mb-4">Overview</h2>
              <p className="text-gray-muted leading-relaxed mb-6">{description}</p>
              <FeatureList items={features} />
              <Disclaimer />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              {image && (
                <div className="overflow-hidden rounded-lg shadow-lg mb-6">
                  <img 
                    src={image} 
                    alt={title}
                    className="w-full h-[280px] object-cover img-hover"
                    loading="lazy"
                  />
                </div>
              )}
              <div className="bg-ivory rounded-lg p-8 border border-gray-100">
                <h3 className="font-heading font-semibold text-lg text-navy mb-4">What's involved</h3>
                <p className="text-sm text-gray-muted leading-relaxed mb-6">
                  Each residency pathway has specific requirements that must be met. During a consultation, we review your individual circumstances and provide clear guidance on the relevant steps.
                </p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-3 text-sm text-navy">
                    <Check size={16} className="text-gold shrink-0 mt-0.5" />
                    Initial eligibility assessment
                  </li>
                  <li className="flex items-start gap-3 text-sm text-navy">
                    <Check size={16} className="text-gold shrink-0 mt-0.5" />
                    Documentation review and preparation
                  </li>
                  <li className="flex items-start gap-3 text-sm text-navy">
                    <Check size={16} className="text-gold shrink-0 mt-0.5" />
                    Application guidance and support
                  </li>
                  <li className="flex items-start gap-3 text-sm text-navy">
                    <Check size={16} className="text-gold shrink-0 mt-0.5" />
                    Ongoing communication throughout
                  </li>
                </ul>
                <Link
                  to="/contact"
                  className="btn-primary inline-flex items-center gap-2 bg-gold text-navy px-5 py-2.5 rounded font-semibold text-sm group"
                >
                  Discuss Your Situation <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
              {additionalInfo && (
                <motion.div 
                  className="mt-6 p-6 bg-navy rounded-lg"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <p className="text-white/80 text-sm leading-relaxed">{additionalInfo}</p>
                </motion.div>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      <CTASection />
    </main>
  );
}
