export interface Service {
  id: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  features: string[];
  path: string;
  icon: string;
}

export interface FAQ {
  question: string;
  answer: string;
}

export interface Testimonial {
  id: string;
  quote: string;
  name: string;
  country: string;
  pathway: string;
  avatar: string;
  role: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
}

export interface ProcessStep {
  number: string;
  title: string;
  description: string;
}

export const services: Service[] = [
  {
    id: 'property-investor',
    title: 'Property Investor',
    shortDescription: 'Residency through qualifying property investment in the UAE.',
    fullDescription: 'For those investing in UAE real estate, the property investor pathway offers a route to long-term residency. Requirements and minimum investment thresholds are subject to applicable UAE regulations.',
    features: ['Qualifying property investment', 'Long-term residency option', 'Family inclusion possible', 'Flexible property options'],
    path: '/property-investor',
    icon: 'building',
  },
  {
    id: 'investor',
    title: 'Investor',
    shortDescription: 'For business investors contributing to the UAE economy.',
    fullDescription: 'The investor visa pathway is designed for individuals making qualifying investments in the UAE. This includes business investments and capital contributions, subject to eligibility and applicable regulations.',
    features: ['Business investment pathway', 'Long-term residency', 'Family sponsorship', 'Economic contribution'],
    path: '/investor-visa',
    icon: 'trending-up',
  },
  {
    id: 'entrepreneur',
    title: 'Entrepreneur',
    shortDescription: 'For founders and business owners establishing ventures in the UAE.',
    fullDescription: 'Entrepreneurs building businesses in the UAE may qualify for residency through the entrepreneur pathway. This supports innovation and economic growth in the Emirates.',
    features: ['Business establishment', 'Startup-friendly', 'Residency for founders', 'Growth-oriented'],
    path: '/entrepreneur-visa',
    icon: 'lightbulb',
  },
  {
    id: 'skilled-professional',
    title: 'Skilled Professional',
    shortDescription: 'For qualified professionals and executives working in the UAE.',
    fullDescription: 'Skilled professionals in designated fields may be eligible for long-term residency. This pathway recognises expertise and professional contribution across various sectors.',
    features: ['Professional qualification-based', 'Executive-level positions', 'Sector-specific eligibility', 'Long-term residency option'],
    path: '/skilled-professional',
    icon: 'briefcase',
  },
  {
    id: 'outstanding-student',
    title: 'Outstanding Student',
    shortDescription: 'For high-achieving students in UAE institutions.',
    fullDescription: 'Exceptional academic performance at recognised UAE institutions may qualify for residency consideration. This pathway supports academic excellence and talent retention.',
    features: ['Academic achievement-based', 'Recognised institutions', 'Talent retention', 'Future-focused'],
    path: '/golden-visa',
    icon: 'graduation-cap',
  },
  {
    id: 'specialized-talent',
    title: 'Specialized Talent',
    shortDescription: 'For individuals with recognised expertise in specialised fields.',
    fullDescription: 'Individuals with exceptional abilities in arts, culture, science, medicine and other specialised fields may qualify. Recognition and approval are subject to relevant authority assessment.',
    features: ['Specialised expertise', 'Multiple fields recognised', 'Authority-assessed', 'Long-term residency'],
    path: '/golden-visa',
    icon: 'award',
  },
];

export const processSteps: ProcessStep[] = [
  { number: '01', title: 'Initial Consultation', description: 'We discuss your goals, circumstances and the residency options that may be relevant to you.' },
  { number: '02', title: 'Eligibility Review', description: 'We review the relevant residency pathway and documentation requirements based on your situation.' },
  { number: '03', title: 'Document Preparation', description: 'We help organise and verify the required information and documentation for your application.' },
  { number: '04', title: 'Application Support', description: 'We guide you through the relevant application process and liaise on your behalf where appropriate.' },
  { number: '05', title: 'Follow-Up', description: 'We keep you informed as the process progresses and assist with any additional requirements.' },
];

export const faqs: FAQ[] = [
  {
    question: 'What is the UAE Golden Visa?',
    answer: 'The UAE Golden Visa is a long-term residency programme introduced by the UAE government. It offers eligible individuals the opportunity to obtain long-term residence in the UAE without the need for a local sponsor. Specific eligibility criteria and conditions are set by the relevant UAE authorities and may be updated from time to time.',
  },
  {
    question: 'Who may qualify for a UAE Golden Visa?',
    answer: 'Several categories of individuals may be eligible, including property investors, business investors, entrepreneurs, skilled professionals, outstanding students and individuals with specialised talents. Final eligibility is determined by the relevant UAE authorities based on applicable regulations and individual circumstances.',
  },
  {
    question: 'Can property investors apply?',
    answer: 'Yes, property investment is one of the recognised pathways. There are specific requirements regarding the type and value of property investment, which are subject to current UAE regulations. We can review your specific situation and advise on the relevant requirements.',
  },
  {
    question: 'Can my family be included in the application?',
    answer: 'The Golden Visa programme generally allows for family sponsorship, including spouses and children. Specific provisions regarding family members and their eligibility are determined under applicable UAE regulations. We can guide you through the relevant requirements for your family.',
  },
  {
    question: 'How long does the process take?',
    answer: 'Processing times vary depending on the residency pathway, completeness of documentation and current authority processing times. During your consultation, we can provide guidance on typical timelines based on your specific pathway and circumstances.',
  },
  {
    question: 'What documents are usually required?',
    answer: 'Required documentation varies by pathway but commonly includes passport copies, proof of investment or employment, medical insurance, and relevant qualification certificates. During the eligibility review, we provide a clear checklist of what will be needed for your specific situation.',
  },
  {
    question: 'Can you help with UAE business setup?',
    answer: 'Yes, we provide guidance on UAE business setup alongside residency services. This includes advice on free zone and mainland company formation, licensing requirements and the relationship between business setup and residency options.',
  },
  {
    question: 'How do I know which residency pathway applies to me?',
    answer: 'The most appropriate pathway depends on your individual circumstances, qualifications, investment capacity and goals. During an initial consultation, we review your situation and help identify the most relevant options. Requirements and eligibility can change, so we always verify against current regulations.',
  },
];

export const testimonials: Testimonial[] = [
  {
    id: '1',
    quote: 'Moving to Dubai was a big decision for my family. The team guided us through every step — from document preparation to final approval. What I appreciated most was their honesty about timelines. Nothing was overpromised, and everything was delivered as discussed.',
    name: 'Alexander Petrov',
    country: 'Russia',
    pathway: 'Property Investor Residency',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face',
    role: 'Real Estate Investor',
  },
  {
    id: '2',
    quote: 'As a tech founder relocating from London, I needed a consultancy that understood both business setup and residency. They handled everything seamlessly — my company formation, visa processing, and even family sponsorship. Truly professional service.',
    name: 'James Whitfield',
    country: 'United Kingdom',
    pathway: 'Entrepreneur Residency',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face',
    role: 'Tech Entrepreneur',
  },
  {
    id: '3',
    quote: 'I was initially overwhelmed by the documentation requirements. My consultant broke everything down into simple steps and was always available to answer questions. The entire process took less time than I expected, and communication was excellent throughout.',
    name: 'Priya Sharma',
    country: 'India',
    pathway: 'Skilled Professional Residency',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop&crop=face',
    role: 'Senior Consultant',
  },
  {
    id: '4',
    quote: 'What sets this team apart is their attention to detail. They caught a documentation issue early that could have delayed my application by months. Their proactive approach saved me significant time and stress. Highly recommend for anyone serious about UAE residency.',
    name: 'Michael Chen',
    country: 'Singapore',
    pathway: 'Investor Residency',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=face',
    role: 'Investment Director',
  },
  {
    id: '5',
    quote: 'After consulting with several firms, I chose this team for their transparency. They clearly explained what was possible and what wasn\'t, without making unrealistic promises. The result was exactly as they described — a smooth, professional process.',
    name: 'Fatima Al-Rashid',
    country: 'Lebanon',
    pathway: 'Family Residency',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=face',
    role: 'Business Owner',
  },
  {
    id: '6',
    quote: 'From our first consultation to the final approval, the experience was first-class. They understood my specific situation as a self-employed professional and tailored their guidance accordingly. The whole family is now settled in Dubai thanks to their support.',
    name: 'Robert Müller',
    country: 'Germany',
    pathway: 'Golden Visa',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face',
    role: 'Financial Advisor',
  },
];

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'UAE Golden Visa: What Investors Should Know',
    excerpt: 'An overview of the Golden Visa programme and key considerations for property and business investors exploring UAE residency options.',
    category: 'Golden Visa',
    date: '2026-01-15',
    readTime: '5 min read',
    image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: '2',
    title: 'Dubai Property Investment and Residency',
    excerpt: 'Understanding the relationship between property investment in Dubai and residency pathways, including key requirements and considerations.',
    category: 'Property',
    date: '2026-01-08',
    readTime: '4 min read',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: '3',
    title: 'Understanding UAE Residency Options',
    excerpt: 'A guide to the different residency pathways available in the UAE, helping you identify which option may be most relevant to your situation.',
    category: 'Residency',
    date: '2025-12-20',
    readTime: '6 min read',
    image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: '4',
    title: 'Setting Up a Business in Dubai',
    excerpt: 'Key considerations for entrepreneurs and business owners looking to establish their presence in Dubai, including free zone and mainland options.',
    category: 'Business Setup',
    date: '2025-12-10',
    readTime: '5 min read',
    image: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
];

export const navigation = {
  main: [
    { label: 'Home', path: '/' },
    { label: 'Golden Visa', path: '/golden-visa' },
    { label: 'Residency', path: '/residency' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ],
};
