// Curated high-quality real stock images from Unsplash
// All images are free to use under Unsplash license
export const images = {
  // Hero - Dubai skyline at golden hour
  hero: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
  
  // Golden Visa - Professional in modern UAE setting
  goldenVisa: 'https://images.unsplash.com/photo-1560520653-9e0e4c89eb11?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  
  // Property - Luxury Dubai architecture
  property: 'https://images.unsplash.com/photo-1582407947092-09b4d7cee555?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  
  // Business - Modern Dubai office with city view
  business: 'https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  
  // Family - Family lifestyle in modern setting
  family: 'https://images.unsplash.com/photo-1609220136736-443140cffec6?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  
  // About - Professional consultant portrait
  about: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  
  // Contact - Modern architecture
  contact: 'https://images.unsplash.com/photo-1546412414-e1885259563a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  
  // Dubai supplementary shots
  dubai1: 'https://images.unsplash.com/photo-1518684079-3c830dcef090?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  dubai2: 'https://images.unsplash.com/photo-1583400472525-1c4407a47b3b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  dubai3: 'https://images.unsplash.com/photo-1597659840241-37e2b4ecd643?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  dubai4: 'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  
  // Blog post images - Real relevant imagery
  blogInvestor: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  blogProperty: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  blogResidency: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  blogBusiness: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  
  // Service-specific imagery
  investor: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  entrepreneur: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  professional: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4d3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
  student: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
};
