import { PageHero, Breadcrumbs, CTASection, FeatureList, Disclaimer } from '../components/PageComponents';
import { images } from '../images';
import { Link } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';

export default function BusinessSetupPage() {
  return (
    <main>
      <PageHero
        eyebrow="Business Setup"
        title="UAE Business Setup"
        subtitle="Establishing your business presence in the UAE. We provide guidance on company formation, licensing and the relationship between business setup and residency options."
      />
      <Breadcrumbs items={[{ label: 'Business Setup' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <div className="gold-line mb-4" />
              <h2 className="font-heading font-bold text-2xl text-navy mb-4">Setting Up in the UAE</h2>
              <p className="text-gray-muted leading-relaxed mb-6">
                The UAE offers various options for establishing a business, including free zone and mainland company formation. The most suitable structure depends on your business activities, ownership preferences and residency requirements.
              </p>
              <p className="text-gray-muted leading-relaxed mb-6">
                We provide guidance on the business setup process alongside our residency services, helping you understand how company formation connects to your overall UAE plans.
              </p>
              <FeatureList items={[
                'Free zone company formation guidance',
                'Mainland business setup options',
                'Licensing and activity guidance',
                'Connection between business and residency',
                'Ongoing compliance support',
              ]} />
              <Disclaimer />
            </div>
            <div>
              <div className="overflow-hidden rounded-lg mb-6">
                <img
                  src={images.business}
                  alt="Modern office environment in Dubai"
                  className="w-full h-[300px] object-cover"
                  loading="lazy"
                />
              </div>
              <div className="bg-ivory rounded-lg p-6 border border-gray-100">
                <h3 className="font-heading font-semibold text-lg text-navy mb-4">Business & Residency</h3>
                <p className="text-sm text-gray-muted leading-relaxed mb-4">
                  For many clients, business setup and residency go hand in hand. Establishing a company in the UAE can be part of your residency pathway, whether as an entrepreneur, investor or employer.
                </p>
                <p className="text-sm text-gray-muted leading-relaxed">
                  We help you understand how these elements connect and ensure your business structure supports your residency objectives.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-20 bg-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-heading font-bold text-2xl text-navy mb-8 text-center">What we help with</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { title: 'Company Formation', desc: 'Guidance on free zone and mainland company structures appropriate for your activities.' },
              { title: 'Licensing', desc: 'Understanding the relevant business licenses and activity approvals required.' },
              { title: 'Visa Allocation', desc: 'How your company structure relates to visa eligibility and allocation.' },
              { title: 'Bank Account Setup', desc: 'Guidance on the corporate banking process in the UAE.' },
              { title: 'Office & Flexi-Desk', desc: 'Understanding workspace requirements for different business structures.' },
              { title: 'Ongoing Support', desc: 'Compliance, renewals and any changes to your business structure.' },
            ].map((item) => (
              <div key={item.title} className="bg-white p-6 rounded-lg border border-gray-100">
                <h3 className="font-heading font-semibold text-navy mb-2">{item.title}</h3>
                <p className="text-sm text-gray-muted">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </main>
  );
}
