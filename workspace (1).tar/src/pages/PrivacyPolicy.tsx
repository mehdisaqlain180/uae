import { PageHero, Breadcrumbs } from '../components/PageComponents';
import { config } from '../config';

export default function PrivacyPolicyPage() {
  return (
    <main>
      <PageHero
        eyebrow="Legal"
        title="Privacy Policy"
        subtitle="How we collect, use and protect your personal information."
      />
      <Breadcrumbs items={[{ label: 'Privacy Policy' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-sm max-w-none">
            <p className="text-sm text-gray-muted mb-8">Last updated: January 2026</p>

            <div className="space-y-8">
              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">1. Introduction</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  {config.legal.companyName} ("we", "us", "our") is committed to protecting your privacy. This policy explains how we collect, use and safeguard your personal information when you use our website and services.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">2. Information We Collect</h2>
                <p className="text-sm text-gray-muted leading-relaxed mb-3">We may collect the following information:</p>
                <ul className="list-disc pl-5 text-sm text-gray-muted space-y-1">
                  <li>Name, email address, phone number and country of residence</li>
                  <li>Information about your residency or business interests</li>
                  <li>Communication preferences</li>
                  <li>Technical information such as IP address and browser type</li>
                </ul>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">3. How We Use Your Information</h2>
                <p className="text-sm text-gray-muted leading-relaxed mb-3">We use your information to:</p>
                <ul className="list-disc pl-5 text-sm text-gray-muted space-y-1">
                  <li>Respond to your enquiries and provide consultancy services</li>
                  <li>Assess your eligibility for relevant residency pathways</li>
                  <li>Communicate with you regarding your case</li>
                  <li>Improve our website and services</li>
                  <li>Comply with legal obligations</li>
                </ul>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">4. Data Sharing</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  We do not sell your personal information. We may share information with relevant UAE authorities as part of your application process, with your consent. We may also share information with professional service providers who assist in delivering our services, under appropriate confidentiality arrangements.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">5. Data Security</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  We implement appropriate technical and organisational measures to protect your personal information against unauthorised access, alteration or destruction. However, no method of electronic transmission is completely secure.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">6. Your Rights</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  You have the right to access, correct or request deletion of your personal information. You may also object to certain processing activities. To exercise these rights, please contact us using the details below.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">7. Cookies</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  Our website uses essential cookies for basic functionality. We may use analytics cookies to understand how visitors use our site. You can manage your cookie preferences through the cookie banner on our website.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">8. Changes to This Policy</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  We may update this policy from time to time. Changes will be posted on this page with an updated revision date.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">9. Contact</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  For privacy-related enquiries, please contact us at{' '}
                  <a href={`mailto:${config.contact.email}`} className="text-gold hover:underline">{config.contact.email}</a>.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
