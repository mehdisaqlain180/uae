import { Link } from 'react-router-dom';
import { ArrowRight, Check, Shield, Users, Lock, Globe, Building, TrendingUp, Lightbulb, Briefcase, GraduationCap, Award, ChevronDown, ChevronUp, FileText, Heart, CreditCard, RefreshCw, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { services, processSteps, faqs, testimonials, blogPosts } from '../data';
import { config } from '../config';
import { images } from '../images';
import WhatsAppIcon from '../components/WhatsAppIcon';
import CountUp from '../components/CountUp';
import { useState } from 'react';

const iconMap: Record<string, React.ReactNode> = {
  building: <Building size={24} />,
  'trending-up': <TrendingUp size={24} />,
  lightbulb: <Lightbulb size={24} />,
  briefcase: <Briefcase size={24} />,
  'graduation-cap': <GraduationCap size={24} />,
  award: <Award size={24} />,
};

export default function Home() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <main>
      {/* Hero Section */}
      <section className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#1e2126]">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img
            src={images.hero}
            alt="Dubai skyline"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-[#1e2126]/85" />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32 w-full text-center">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
            className="flex flex-col items-center"
          >
            {/* Main Headline */}
            <motion.h1 
              className="font-heading font-black uppercase text-4xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl leading-[0.95] sm:leading-[0.9] mb-6 sm:mb-8 tracking-tight"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
            >
              <span className="text-gold">GOLDEN</span>{' '}
              <span className="text-white" style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700 }}>VISA UAE</span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p 
              className="text-white/80 text-base sm:text-lg md:text-xl lg:text-2xl leading-relaxed max-w-3xl mb-8 sm:mb-12 font-light px-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
            >
              Secure 10-Year Residency with the Dubai Golden Visa in the UAE
            </motion.p>

            {/* Single CTA Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.9 }}
              className="w-full sm:w-auto"
            >
              <Link
                to="/contact"
                className="inline-block w-full sm:w-auto bg-gold text-navy px-6 sm:px-10 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg hover:bg-gold-light transition-all duration-300 shadow-2xl hover:shadow-gold/50 hover:scale-105"
              >
                Contact Golden Visa Expert
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Government Collaboration Section */}
      <section className="bg-white py-12 sm:py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-navy mb-4 sm:mb-6 px-2">
              Collaborating extensively with various Government Departments
            </h2>
            <p className="text-base sm:text-lg text-gray-600 leading-relaxed px-2">
              GOLDEN VISA UAE has collaborated with many UAE government agencies to improve the residence humanitarian pioneers...
            </p>
          </motion.div>
        </div>
      </section>

      {/* Logo Marquee Section */}
      <section className="bg-white py-12 overflow-hidden relative">
        {/* Left fade */}
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
        
        {/* Right fade */}
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />
        
        {/* Scrolling container */}
        <div className="marquee-container">
          <div className="marquee-content flex items-center gap-16">
            {/* First set of logos */}
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dubai-knowledge.webp" alt="Dubai Knowledge" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dept-con-dev.webp" alt="Department of Economic Development" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/duba-econ.webp" alt="Dubai Economy" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dubai-courts.webp" alt="Dubai Courts" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dubai-chamber.webp" alt="Dubai Chamber" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dubai-munciple.webp" alt="Dubai Municipality" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/govt-of-dubai.webp" alt="Government of Dubai" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/fafic.webp" alt="FAFIC" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            
            {/* Duplicate for seamless loop */}
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dubai-knowledge.webp" alt="Dubai Knowledge" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dept-con-dev.webp" alt="Department of Economic Development" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/duba-econ.webp" alt="Dubai Economy" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dubai-courts.webp" alt="Dubai Courts" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dubai-chamber.webp" alt="Dubai Chamber" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/dubai-munciple.webp" alt="Dubai Municipality" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/govt-of-dubai.webp" alt="Government of Dubai" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
            <img src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/fafic.webp" alt="FAFIC" className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all" />
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-12 sm:py-16 lg:py-28 bg-gradient-to-br from-navy via-navy-light to-navy relative overflow-hidden">
        <div className="absolute inset-0 w-full h-full opacity-10">
          <img src={images.dubai1} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
        </div>
        <div className="absolute top-0 left-1/4 w-64 sm:w-96 h-64 sm:h-96 bg-gold/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-64 sm:w-96 h-64 sm:h-96 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {[
              { value: 500, suffix: '+', label: 'Satisfied Clients', icon: 'https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-satisfaction.svg' },
              { value: 98, suffix: '%', label: 'Success Rate', icon: 'https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-user.svg' },
              { value: 350, suffix: '+', label: 'Golden Visas Processed', icon: 'https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-visas.svg' },
              { value: 8, suffix: '+', label: 'Years of Experience', icon: 'https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-awards.svg' },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                className="group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 * index }}
              >
                <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 group-hover:border-gold/50 rounded-2xl p-4 sm:p-6 lg:p-8 h-full flex flex-col items-center justify-center transition-all duration-500 group-hover:bg-white/10 min-h-[200px] sm:min-h-[240px] lg:min-h-[280px]">
                  <div className="relative inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-gold/20 to-gold/10 text-gold mb-4 sm:mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110">
                    <div className="absolute inset-0 bg-gold/30 rounded-2xl blur-xl group-hover:bg-gold/50 transition-all duration-500" />
                    <div className="relative">
                      <img src={stat.icon} alt={stat.label} className="w-10 h-10 sm:w-12 sm:h-12" />
                    </div>
                  </div>
                  <div className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl text-gold mb-2 sm:mb-3">
                    <CountUp end={stat.value} suffix={stat.suffix} duration={2} />
                  </div>
                  <div className="text-white/70 text-xs sm:text-sm font-medium uppercase tracking-wider text-center px-2">
                    {stat.label}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* What is UAE Golden Visa Section */}
      <section className="py-12 sm:py-16 lg:py-28 bg-gradient-to-b from-cream/30 via-white to-cream/30 relative overflow-hidden">
        <div className="absolute top-20 right-0 w-64 sm:w-80 h-64 sm:h-80 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-0 w-64 sm:w-80 h-64 sm:h-80 bg-navy/5 rounded-full blur-3xl" />
        
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-10 sm:mb-12 lg:mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 sm:gap-3 mb-4">
              <div className="w-8 sm:w-12 h-[1px] bg-gradient-to-r from-transparent to-gold" />
              <span className="text-gold text-xs font-semibold uppercase tracking-widest">About the Program</span>
              <div className="w-8 sm:w-12 h-[1px] bg-gradient-to-l from-transparent to-gold" />
            </div>
            <h2 className="font-heading font-light text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-navy mb-4 px-2">
              What is the <span className="text-gold font-normal">UAE Golden Visa?</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 sm:gap-8 mb-10 sm:mb-12 lg:mb-16">
            {/* Long-Term Stability */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-gold/20 via-transparent to-gold/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" />
              <div className="relative bg-white border border-gray-200 group-hover:border-gold rounded-2xl p-6 sm:p-8 h-full transition-all duration-500 group-hover:shadow-xl">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-gold/10 to-gold/5 flex items-center justify-center mb-4 sm:mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110 group-hover:rotate-3">
                  <Shield size={28} className="sm:hidden text-gold group-hover:text-navy transition-colors duration-500" />
                  <Shield size={32} className="hidden sm:block text-gold group-hover:text-navy transition-colors duration-500" />
                </div>
                <h3 className="font-heading font-bold text-lg sm:text-xl text-navy mb-3 sm:mb-4 group-hover:text-gold transition-colors duration-300">
                  Long-Term Stability
                </h3>
                <p className="text-sm sm:text-base text-gray-muted leading-relaxed">
                  The UAE Golden Visa is a government-backed long-term residence by investment program that allows foreigners to live, work, and study without requiring a national sponsor. Introduced in 2019, the UAE Golden Visa was created to attract global talent and investment, strengthening the country's role as an international hub for business, research, and innovation.
                </p>
              </div>
            </motion.div>

            {/* Global Talent Attraction */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-gold/20 via-transparent to-gold/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" />
              <div className="relative bg-white border border-gray-200 group-hover:border-gold rounded-2xl p-6 sm:p-8 h-full transition-all duration-500 group-hover:shadow-xl">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-gold/10 to-gold/5 flex items-center justify-center mb-4 sm:mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110 group-hover:rotate-3">
                  <Globe size={28} className="sm:hidden text-gold group-hover:text-navy transition-colors duration-500" />
                  <Globe size={32} className="hidden sm:block text-gold group-hover:text-navy transition-colors duration-500" />
                </div>
                <h3 className="font-heading font-bold text-lg sm:text-xl text-navy mb-3 sm:mb-4 group-hover:text-gold transition-colors duration-300">
                  Global Talent Attraction
                </h3>
                <p className="text-sm sm:text-base text-gray-muted leading-relaxed">
                  Unlike standard residence visas (usually 2–3 years), the Golden Visa In Dubai offers residence for 5 or 10 years, with the option to renew. This gives individuals and families greater stability, making it easier to plan careers, education, and investments in Dubai and across the United Arab Emirates.
                </p>
              </div>
            </motion.div>

            {/* Economic Growth */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-gold/20 via-transparent to-gold/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" />
              <div className="relative bg-white border border-gray-200 group-hover:border-gold rounded-2xl p-6 sm:p-8 h-full transition-all duration-500 group-hover:shadow-xl">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-gold/10 to-gold/5 flex items-center justify-center mb-4 sm:mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110 group-hover:rotate-3">
                  <TrendingUp size={28} className="sm:hidden text-gold group-hover:text-navy transition-colors duration-500" />
                  <TrendingUp size={32} className="hidden sm:block text-gold group-hover:text-navy transition-colors duration-500" />
                </div>
                <h3 className="font-heading font-bold text-lg sm:text-xl text-navy mb-3 sm:mb-4 group-hover:text-gold transition-colors duration-300">
                  Economic Growth
                </h3>
                <p className="text-sm sm:text-base text-gray-muted leading-relaxed">
                  At the time of its launch, the program was mainly aimed at investors and highly skilled professionals. Over the years, Golden Visa eligibility in the UAE has expanded to include entrepreneurs, doctors, scientists, researchers, cultural figures, athletes, and top-performing students. These updates reflect the government's commitment to keeping the program competitive on a global scale and attracting people whose contributions drive long-term growth.
                </p>
              </div>
            </motion.div>
          </div>

          {/* Core Objectives */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-gold/10 via-transparent to-gold/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="relative bg-white border-2 border-gold/30 group-hover:border-gold rounded-2xl p-8 lg:p-12 shadow-lg group-hover:shadow-2xl transition-all duration-500 mb-12">
              <h3 className="font-heading font-light text-2xl lg:text-3xl text-navy mb-8 text-center">
                The core objectives of the <span className="text-gold font-normal">Golden Visa In UAE</span> are:
              </h3>
              <div className="grid md:grid-cols-3 gap-8 mb-8">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center mb-4 shadow-lg">
                    <Briefcase size={28} className="text-navy" />
                  </div>
                  <p className="text-navy font-medium leading-relaxed">
                    To attract foreign investment and encourage entrepreneurship.
                  </p>
                </div>
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center mb-4 shadow-lg">
                    <Globe size={28} className="text-navy" />
                  </div>
                  <p className="text-navy font-medium leading-relaxed">
                    To bring in global expertise in medicine, science, technology, and culture.
                  </p>
                </div>
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center mb-4 shadow-lg">
                    <Lightbulb size={28} className="text-navy" />
                  </div>
                  <p className="text-navy font-medium leading-relaxed">
                    To build a stable, diverse, and innovation-driven economy.
                  </p>
                </div>
              </div>
              <p className="text-gray-muted text-center text-lg leading-relaxed">
                The Golden Visa is more than just a residency permit. It represents a pathway to long-term stay in the UAE with stability and benefits.
              </p>
            </div>
          </motion.div>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <Link
              to="/contact"
              className="group relative inline-flex items-center gap-3 bg-gradient-to-r from-gold to-gold-light hover:from-gold-light hover:to-gold text-navy px-12 py-5 rounded-full font-bold text-lg transition-all duration-500 shadow-xl hover:shadow-2xl hover:scale-105"
            >
              Book Your Free Consultation Here
              <ArrowRight size={20} className="transition-transform group-hover:translate-x-2" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* UAE Golden Visa Application Process */}
      <section className="py-20 lg:py-28 bg-gradient-to-br from-navy via-navy-light to-navy relative overflow-hidden">
        <div className="absolute inset-0 w-full h-full opacity-10">
          <img src={images.dubai1} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
        </div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-3 mb-4">
              <div className="w-12 h-[1px] bg-gradient-to-r from-transparent to-gold" />
              <span className="text-gold text-xs font-semibold uppercase tracking-widest">Application Process</span>
              <div className="w-12 h-[1px] bg-gradient-to-l from-transparent to-gold" />
            </div>
            <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl text-white mb-6">
              UAE Golden Visa <span className="text-gold font-normal">Application Process</span>
            </h2>
            <p className="text-white/70 text-lg max-w-3xl mx-auto leading-relaxed">
              Applying for a UAE Golden Visa can seem like a complicated process, but it doesn't have to be. Here's an overview of the key steps involved, with the assistance of someone who knows the process inside and out.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Step 1 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="group text-center"
            >
              <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 group-hover:border-gold/50 rounded-2xl p-8 h-full transition-all duration-500 group-hover:bg-white/10">
                <div className="flex flex-col items-center">
                  <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-gold/20 to-gold/10 text-gold mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110">
                    <div className="absolute inset-0 bg-gold/30 rounded-2xl blur-xl group-hover:bg-gold/50 transition-all duration-500" />
                    <div className="relative">
                      <img 
                        src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-submission.svg" 
                        alt="Documents Collection" 
                        className="w-12 h-12"
                      />
                    </div>
                  </div>
                  <h3 className="font-heading font-bold text-xl text-white group-hover:text-gold transition-colors duration-300">
                    Documents Collection &<br />Submission of Application
                  </h3>
                </div>
              </div>
            </motion.div>

            {/* Step 2 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="group text-center"
            >
              <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 group-hover:border-gold/50 rounded-2xl p-8 h-full transition-all duration-500 group-hover:bg-white/10">
                <div className="flex flex-col items-center">
                  <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-gold/20 to-gold/10 text-gold mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110">
                    <div className="absolute inset-0 bg-gold/30 rounded-2xl blur-xl group-hover:bg-gold/50 transition-all duration-500" />
                    <div className="relative">
                      <img 
                        src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-initial-approval.svg" 
                        alt="Initial Approval" 
                        className="w-12 h-12"
                      />
                    </div>
                  </div>
                  <h3 className="font-heading font-bold text-xl text-white group-hover:text-gold transition-colors duration-300">
                    Initial Approval
                  </h3>
                </div>
              </div>
            </motion.div>

            {/* Step 3 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="group text-center"
            >
              <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 group-hover:border-gold/50 rounded-2xl p-8 h-full transition-all duration-500 group-hover:bg-white/10">
                <div className="flex flex-col items-center">
                  <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-gold/20 to-gold/10 text-gold mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110">
                    <div className="absolute inset-0 bg-gold/30 rounded-2xl blur-xl group-hover:bg-gold/50 transition-all duration-500" />
                    <div className="relative">
                      <img 
                        src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-medical.svg" 
                        alt="Medical" 
                        className="w-12 h-12"
                      />
                    </div>
                  </div>
                  <h3 className="font-heading font-bold text-xl text-white group-hover:text-gold transition-colors duration-300">
                    Medical
                  </h3>
                </div>
              </div>
            </motion.div>

            {/* Step 4 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="group text-center"
            >
              <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 group-hover:border-gold/50 rounded-2xl p-8 h-full transition-all duration-500 group-hover:bg-white/10">
                <div className="flex flex-col items-center">
                  <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-gold/20 to-gold/10 text-gold mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110">
                    <div className="absolute inset-0 bg-gold/30 rounded-2xl blur-xl group-hover:bg-gold/50 transition-all duration-500" />
                    <div className="relative">
                      <img 
                        src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-visa-cancellation.svg" 
                        alt="Existing Visa Cancellation" 
                        className="w-12 h-12"
                      />
                    </div>
                  </div>
                  <h3 className="font-heading font-bold text-xl text-white group-hover:text-gold transition-colors duration-300">
                    Existing Visa<br />Cancellation
                  </h3>
                </div>
              </div>
            </motion.div>

            {/* Step 5 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="group text-center"
            >
              <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 group-hover:border-gold/50 rounded-2xl p-8 h-full transition-all duration-500 group-hover:bg-white/10">
                <div className="flex flex-col items-center">
                  <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-gold/20 to-gold/10 text-gold mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110">
                    <div className="absolute inset-0 bg-gold/30 rounded-2xl blur-xl group-hover:bg-gold/50 transition-all duration-500" />
                    <div className="relative">
                      <img 
                        src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-vip-biometric.svg" 
                        alt="VIP Biometric" 
                        className="w-12 h-12"
                      />
                    </div>
                  </div>
                  <h3 className="font-heading font-bold text-xl text-white group-hover:text-gold transition-colors duration-300">
                    VIP Biometric
                  </h3>
                </div>
              </div>
            </motion.div>

            {/* Step 6 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="group text-center"
            >
              <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 group-hover:border-gold/50 rounded-2xl p-8 h-full transition-all duration-500 group-hover:bg-white/10">
                <div className="flex flex-col items-center">
                  <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-gold/20 to-gold/10 text-gold mb-6 group-hover:from-gold group-hover:to-gold-light group-hover:text-navy transition-all duration-500 group-hover:scale-110">
                    <div className="absolute inset-0 bg-gold/30 rounded-2xl blur-xl group-hover:bg-gold/50 transition-all duration-500" />
                    <div className="relative">
                      <img 
                        src="https://www.goldenvisauae.net/wp-content/themes/goldenvisauae/dist/img/icon-visa.svg" 
                        alt="Final Visa Issuance" 
                        className="w-12 h-12"
                      />
                    </div>
                  </div>
                  <h3 className="font-heading font-bold text-xl text-white group-hover:text-gold transition-colors duration-300">
                    Final Visa<br />Issuance
                  </h3>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Golden Visa vs. Other UAE Residency Visas */}
      <section className="py-20 lg:py-28 bg-white relative overflow-hidden">
        <div className="absolute top-20 right-0 w-80 h-80 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-0 w-80 h-80 bg-navy/5 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-3 mb-4">
              <div className="w-12 h-[1px] bg-gradient-to-r from-transparent to-gold" />
              <span className="text-gold text-xs font-semibold uppercase tracking-widest">Comparison</span>
              <div className="w-12 h-[1px] bg-gradient-to-l from-transparent to-gold" />
            </div>
            <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl text-navy mb-6">
              Golden Visa vs. <span className="text-gold font-normal">Other UAE Residency Visas</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* UAE Golden Visa */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="group"
            >
              <div className="relative bg-gradient-to-br from-gold/10 to-gold/5 border-2 border-gold/30 group-hover:border-gold rounded-2xl p-8 h-full transition-all duration-500 shadow-lg">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gold/20 rounded-full blur-2xl" />
                <div className="relative">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-full bg-gold flex items-center justify-center">
                      <Award size={24} className="text-navy" />
                    </div>
                    <h3 className="font-heading font-bold text-2xl text-gold">
                      UAE Golden Visa
                    </h3>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Check size={20} className="text-gold shrink-0 mt-1" />
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Duration</p>
                        <p className="text-navy font-medium">5–10 years (renewable)</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check size={20} className="text-gold shrink-0 mt-1" />
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Sponsorship</p>
                        <p className="text-navy font-medium">Not required</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check size={20} className="text-gold shrink-0 mt-1" />
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Eligibility</p>
                        <p className="text-navy font-medium">Investors, entrepreneurs, skilled pros</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check size={20} className="text-gold shrink-0 mt-1" />
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Benefits</p>
                        <p className="text-navy font-medium">Live/work/study freedom</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check size={20} className="text-gold shrink-0 mt-1" />
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Best For</p>
                        <p className="text-navy font-medium">HNWIs, long-term planners</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Other UAE Residency Visas */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="group"
            >
              <div className="relative bg-gray-50 border border-gray-200 group-hover:border-gray-300 rounded-2xl p-8 h-full transition-all duration-500">
                <div className="relative">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                      <FileText size={24} className="text-gray-600" />
                    </div>
                    <h3 className="font-heading font-bold text-2xl text-gray-700">
                      Other UAE Residency Visas
                    </h3>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center shrink-0 mt-1">
                        <span className="text-gray-500 text-xs">•</span>
                      </div>
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Duration</p>
                        <p className="text-navy/80 font-medium">1–3 years (renewable)</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center shrink-0 mt-1">
                        <span className="text-gray-500 text-xs">•</span>
                      </div>
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Sponsorship</p>
                        <p className="text-navy/80 font-medium">Required (employer/family)</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center shrink-0 mt-1">
                        <span className="text-gray-500 text-xs">•</span>
                      </div>
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Eligibility</p>
                        <p className="text-navy/80 font-medium">Employment, family, property, freelancers</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center shrink-0 mt-1">
                        <span className="text-gray-500 text-xs">•</span>
                      </div>
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Benefits</p>
                        <p className="text-navy/80 font-medium">Standard residency</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center shrink-0 mt-1">
                        <span className="text-gray-500 text-xs">•</span>
                      </div>
                      <div>
                        <p className="text-gray-muted text-sm mb-1">Best For</p>
                        <p className="text-navy/80 font-medium">Short-term stays, job-linked</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Processing Time, Fees & Costs */}
      <section className="py-20 lg:py-28 bg-gradient-to-br from-navy via-navy-light to-navy relative overflow-hidden">
        <div className="absolute inset-0 w-full h-full opacity-10">
          <img src={images.dubai1} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
        </div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
        
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-3 mb-4">
              <div className="w-12 h-[1px] bg-gradient-to-r from-transparent to-gold" />
              <span className="text-gold text-xs font-semibold uppercase tracking-widest">Costs & Timeline</span>
              <div className="w-12 h-[1px] bg-gradient-to-l from-transparent to-gold" />
            </div>
            <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl text-white mb-6">
              Processing Time, Fees & <span className="text-gold font-normal">Costs</span>
            </h2>
            <p className="text-white/70 text-lg max-w-3xl mx-auto leading-relaxed">
              The Dubai UAE Golden Visa typically takes 2 to 6 weeks to process from start to finish, depending on the applicant's category and how quickly the required documents are submitted. In many cases, property investors and professionals can receive approval in as little as 2–4 weeks, while more complex applications, such as entrepreneurs or specialized talents, may take slightly longer.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h3 className="font-heading font-bold text-2xl text-white mb-8 text-center">
              Understanding Golden Visa Costs
            </h3>
            <p className="text-white/70 text-center mb-10 max-w-3xl mx-auto">
              The costs for applying for the UAE Golden Visa can vary depending on your specific circumstances and the Emirate in which you apply. While fees generally range from AED 5,000 to AED 15,000, the exact amount will depend on factors such as the application type, medical tests, and visa stamping.
            </p>

            <div className="grid md:grid-cols-2 gap-6 mb-10">
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 hover:border-gold/50 rounded-2xl p-6 transition-all duration-500 hover:bg-white/10">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center shrink-0">
                    <FileText size={24} className="text-gold" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-lg text-white mb-2">
                      Application & Government Fees
                    </h4>
                    <p className="text-white/70">
                      Typically ranging from AED 5,000 to AED 15,000
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 backdrop-blur-sm border border-white/10 hover:border-gold/50 rounded-2xl p-6 transition-all duration-500 hover:bg-white/10">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center shrink-0">
                    <Heart size={24} className="text-gold" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-lg text-white mb-2">
                      Medical Fitness Test
                    </h4>
                    <p className="text-white/70">
                      Around AED 700
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 backdrop-blur-sm border border-white/10 hover:border-gold/50 rounded-2xl p-6 transition-all duration-500 hover:bg-white/10">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center shrink-0">
                    <CreditCard size={24} className="text-gold" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-lg text-white mb-2">
                      Visa Stamping & Emirates ID
                    </h4>
                    <p className="text-white/70">
                      AED 2,500 – AED 3,500
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 backdrop-blur-sm border border-white/10 hover:border-gold/50 rounded-2xl p-6 transition-all duration-500 hover:bg-white/10">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center shrink-0">
                    <Shield size={24} className="text-gold" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-lg text-white mb-2">
                      Health Insurance
                    </h4>
                    <p className="text-white/70">
                      Between AED 800 and AED 2,500 annually
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border-2 border-gold/30 rounded-2xl p-8 text-center">
              <p className="text-white/80 mb-6">
                <strong className="text-gold">Note:</strong> These are general estimates and costs may vary. To get a tailored breakdown and accurate quote for your situation, please contact us directly. We'll guide you through every step of the process.
              </p>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 bg-gold text-navy px-8 py-3 rounded-full font-bold hover:bg-gold-light transition-all duration-300 group"
              >
                Get Your Tailored Quote
                <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Renewal, Suspension & Cancellation */}
      <section className="py-20 lg:py-28 bg-white relative overflow-hidden">
        <div className="absolute top-20 right-0 w-80 h-80 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-0 w-80 h-80 bg-navy/5 rounded-full blur-3xl" />
        
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-3 mb-4">
                <div className="w-12 h-[1px] bg-gradient-to-r from-transparent to-gold" />
                <span className="text-gold text-xs font-semibold uppercase tracking-widest">Important Information</span>
                <div className="w-12 h-[1px] bg-gradient-to-l from-transparent to-gold" />
              </div>
              <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl text-navy mb-6">
                Renewal, Suspension & <span className="text-gold font-normal">Cancellation</span>
              </h2>
            </div>

            <div className="bg-ivory border-2 border-gold/20 rounded-2xl p-8 lg:p-12">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center shrink-0">
                    <RefreshCw size={24} className="text-gold" />
                  </div>
                  <div>
                    <h3 className="font-heading font-bold text-xl text-gold mb-3">
                      Visa Renewal
                    </h3>
                    <p className="text-gray-muted leading-relaxed">
                      Your UAE Golden Visa (typically valid for 5-10 years) can be renewed as long as you continue to meet the eligibility criteria. This may include maintaining an active property investment, running a business, or holding endorsements in specialized fields.
                    </p>
                  </div>
                </div>

                <div className="border-t border-gold/20 pt-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center shrink-0">
                      <AlertCircle size={24} className="text-gold" />
                    </div>
                    <div>
                      <h3 className="font-heading font-bold text-xl text-gold mb-3">
                        Suspension & Cancellation
                      </h3>
                      <p className="text-gray-muted leading-relaxed">
                        It's important to note that the visa can be suspended or canceled if any conditions aren't met—like if the property value drops below the required threshold or if required endorsements are lost.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Residency Pathways */}
      <section className="py-20 lg:py-28 bg-gradient-to-br from-navy via-navy-light to-navy relative overflow-hidden">
        <div className="absolute inset-0 w-full h-full opacity-10">
          <img src={images.dubai1} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
        </div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-14"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-3 mb-4">
              <div className="w-12 h-[1px] bg-gradient-to-r from-transparent to-gold" />
              <span className="text-gold text-xs font-semibold uppercase tracking-widest">Residency Options</span>
              <div className="w-12 h-[1px] bg-gradient-to-l from-transparent to-gold" />
            </div>
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-white mb-4">
              Choose the residency pathway<br className="hidden sm:block" /> that fits your future.
            </h2>
            <p className="text-white/70 max-w-2xl mx-auto">
              Several pathways exist for UAE residency. Each has specific eligibility requirements determined under applicable UAE regulations.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Link
                  to={service.path}
                  className="relative bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 overflow-hidden hover:border-gold/50 hover:bg-white/10 transition-all duration-300 block h-full group"
                >
                  {/* Diagonal ribbon badge in top-right corner */}
                  <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden pointer-events-none z-10">
                    <div className="absolute top-4 right-[-35px] w-[140px] h-8 bg-[#CFA45A] transform rotate-45 shadow-sm" />
                  </div>
                  
                  {/* Card content */}
                  <div className="p-6 pt-8 relative">
                    {/* Icon with circular background */}
                    <div className="mb-5">
                      <div className="w-14 h-14 rounded-full bg-gold/20 flex items-center justify-center text-gold group-hover:bg-gold group-hover:text-navy transition-all duration-300">
                        {iconMap[service.icon]}
                      </div>
                    </div>
                    
                    {/* Title */}
                    <h3 className="font-heading font-semibold text-lg text-white mb-3 group-hover:text-gold transition-colors">
                      {service.title}
                    </h3>
                    
                    {/* Description */}
                    <p className="text-sm text-white/70 leading-relaxed mb-5">
                      {service.shortDescription}
                    </p>
                    
                    {/* CTA */}
                    <span className="text-sm font-semibold text-white flex items-center gap-2 group-hover:text-gold transition-colors">
                      Explore pathway 
                      <ArrowRight size={16} className="transition-transform group-hover:translate-x-2" />
                    </span>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Golden Visa Split Section */}
      <section className="py-20 lg:py-28 bg-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <motion.div 
              className="overflow-hidden rounded-lg shadow-xl"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            >
              <img
                src={images.goldenVisa}
                alt="Professional business environment in the UAE"
                className="w-full h-[400px] lg:h-[500px] object-cover img-hover"
                loading="lazy"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="gold-line mb-4" />
              <h2 className="font-heading font-bold text-3xl sm:text-4xl text-navy mb-4">
                UAE Golden Visa
              </h2>
              <p className="text-gray-muted leading-relaxed mb-6">
                Long-term UAE residency for people building, investing and creating their future in the Emirates. Subject to eligibility and applicable UAE regulations.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  'Long-term residency options',
                  'Family sponsorship pathways',
                  'Flexible travel arrangements',
                  'UAE-based lifestyle and business opportunities',
                  'Professional application guidance',
                ].map((item, index) => (
                  <motion.li 
                    key={item} 
                    className="flex items-start gap-3 text-sm text-navy"
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Check size={16} className="text-gold shrink-0 mt-0.5" />
                    {item}
                  </motion.li>
                ))}
              </ul>
              <Link
                to="/golden-visa"
                className="btn-primary inline-flex items-center gap-2 bg-navy text-white px-6 py-3 rounded font-medium text-sm group"
              >
                Check Your Eligibility <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why Choose Us - Numbered Features */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-14"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="gold-line mx-auto mb-4" />
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-navy mb-4">
              More than paperwork.<br />A clearer path forward.
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { num: '01', title: 'Personal Guidance', desc: 'Your situation is reviewed individually. We take time to understand your goals and identify the most relevant options.' },
              { num: '02', title: 'Clear Communication', desc: 'You receive straightforward information about requirements, timelines and next steps — without unnecessary complexity.' },
              { num: '03', title: 'End-to-End Support', desc: 'From initial assessment through to application follow-up, we manage the process with attention to detail.' },
              { num: '04', title: 'Confidential Handling', desc: 'Your personal information and circumstances are treated with appropriate discretion throughout.' },
            ].map((item, index) => (
              <motion.div 
                key={item.num} 
                className="relative group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <span className="font-heading font-bold text-5xl text-gold/20 mb-3 block group-hover:text-gold/40 transition-colors">{item.num}</span>
                <h3 className="font-heading font-semibold text-lg text-navy mb-2">{item.title}</h3>
                <p className="text-sm text-gray-muted leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Timeline */}
      <section className="py-20 lg:py-28 bg-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-14"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="gold-line mx-auto mb-4" />
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-navy mb-4">
              A simple process.<br />Handled properly.
            </h2>
          </motion.div>

          <div className="relative max-w-3xl mx-auto">
            <div className="absolute left-6 top-0 bottom-0 w-px bg-gold/20 hidden sm:block" />

            <div className="space-y-8">
              {processSteps.map((step, index) => (
                <motion.div 
                  key={step.number} 
                  className="relative flex gap-6"
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <div className="shrink-0 w-12 h-12 rounded-full border-2 border-gold flex items-center justify-center bg-white z-10 shadow-md">
                    <span className="font-heading font-bold text-sm text-gold">{step.number}</span>
                  </div>
                  <div className="pt-2">
                    <h3 className="font-heading font-semibold text-lg text-navy mb-1">{step.title}</h3>
                    <p className="text-sm text-gray-muted leading-relaxed">{step.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <p className="text-xs text-gray-muted uppercase tracking-wider mb-2">What our clients say</p>
            <div className="gold-line mx-auto mb-4" />
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-navy mb-4">
              Trusted by Professionals Worldwide
            </h2>
            <p className="text-gray-muted max-w-2xl mx-auto">
              Real feedback from clients who have successfully navigated their UAE residency journey with our guidance.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((t, index) => (
              <motion.div 
                key={t.id} 
                className="relative bg-white rounded-2xl border-2 border-[#D4AF37] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                {/* Diagonal ribbon badge */}
                <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden pointer-events-none z-10">
                  <div className="absolute top-4 right-[-35px] w-[140px] h-8 bg-[#CFA45A] transform rotate-45 shadow-sm" />
                </div>

                {/* Card content */}
                <div className="p-6 pt-8">
                  {/* Star rating */}
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-5 h-5 text-[#CFA45A]" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>

                  {/* Quote */}
                  <p className="text-navy text-sm leading-relaxed mb-6 italic">
                    "{t.quote}"
                  </p>

                  {/* Author info with avatar */}
                  <div className="border-t border-gray-100 pt-4 flex items-center gap-3">
                    <img 
                      src={t.avatar} 
                      alt={t.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-[#CFA45A]/30"
                      loading="lazy"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-navy">{t.name}</p>
                      <p className="text-xs text-gray-muted">{t.role}</p>
                      <p className="text-xs text-[#CFA45A] font-medium mt-0.5">
                        {t.country} • {t.pathway}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Disclaimer */}
          <motion.p 
            className="text-xs text-gray-muted text-center mt-8"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.5 }}
          >
            * Client testimonials are shared with permission. Names and details have been updated for privacy.
          </motion.p>
        </div>
      </section>

      {/* Blog Section */}
      <section className="py-20 lg:py-28 bg-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="flex items-end justify-between mb-10"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div>
              <div className="gold-line mb-4" />
              <h2 className="font-heading font-bold text-2xl sm:text-3xl text-navy">Insights & Guidance</h2>
            </div>
            <p className="text-xs text-gray-muted hidden sm:block">Sample articles — demo content</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {blogPosts.map((post, index) => (
              <motion.article 
                key={post.id} 
                className="card-hover bg-white rounded-lg overflow-hidden border border-gray-100"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover img-hover"
                    loading="lazy"
                  />
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-medium text-gold">{post.category}</span>
                    <span className="text-xs text-gray-muted">•</span>
                    <span className="text-xs text-gray-muted">{post.readTime}</span>
                  </div>
                  <h3 className="font-heading font-semibold text-sm text-navy leading-snug mb-2 line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-xs text-gray-muted leading-relaxed line-clamp-2">{post.excerpt}</p>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-28 bg-ivory">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="gold-line mx-auto mb-4" />
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-navy mb-4">
              Frequently Asked Questions
            </h2>
          </motion.div>

          <div className="space-y-5">
            {faqs.map((faq, index) => (
              <motion.div 
                key={index} 
                className="relative bg-white rounded-2xl border-2 border-[#D4AF37] overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              >
                {/* Diagonal ribbon badge in top-right corner */}
                <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden pointer-events-none">
                  <div className="absolute top-4 right-[-35px] w-[140px] h-8 bg-[#CFA45A] transform rotate-45 shadow-sm" />
                </div>
                
                {/* Question button */}
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full p-6 pr-20 text-left relative"
                  aria-expanded={openFaq === index}
                >
                  {/* Circular toggle icon on the ribbon */}
                  <div className="absolute top-4 right-4 z-10">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 ${
                      openFaq === index 
                        ? 'bg-white border-2 border-[#CFA45A]' 
                        : 'bg-[#CFA45A] border-2 border-white'
                    }`}>
                      {openFaq === index ? (
                        <ChevronUp size={18} className="text-[#CFA45A]" />
                      ) : (
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                          <line x1="12" y1="5" x2="12" y2="19" />
                          <line x1="5" y1="12" x2="19" y2="12" />
                        </svg>
                      )}
                    </div>
                  </div>
                  
                  {/* Question text */}
                  <h3 className="font-heading font-semibold text-navy text-base leading-relaxed pr-4">
                    {faq.question}
                  </h3>
                </button>
                
                {/* Answer content */}
                <div className={`accordion-content ${openFaq === index ? 'open' : ''}`}>
                  <div className="px-6 pb-6 pt-2">
                    <div className="border-t border-gray-100 pt-4">
                      <p className="text-sm text-gray-muted leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <p className="text-xs text-gray-muted text-center mt-8">
            Requirements and eligibility can change. Final eligibility is determined under applicable UAE regulations and by the relevant authorities.
          </p>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-28 bg-navy relative overflow-hidden">
        <div className="absolute inset-0 w-full h-full opacity-10">
          <img src={images.dubai2} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
        </div>
        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-white mb-4">
              Let's discuss your UAE plans.
            </h2>
            <p className="text-white/60 mb-8 max-w-lg mx-auto">
              Tell us what you're looking to achieve and our team will help you understand the most relevant next steps.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-6">
              <Link
                to="/contact"
                className="btn-primary bg-gold text-navy px-7 py-3.5 rounded font-semibold text-sm group"
              >
                <span className="inline-flex items-center gap-2">
                  Book a Consultation
                  <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                </span>
              </Link>
              <a
                href={config.contact.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 border border-white/20 text-white px-7 py-3.5 rounded font-medium text-sm hover:bg-white/10 transition-all duration-300"
              >
                <WhatsAppIcon size={16} />
                WhatsApp Us
              </a>
            </div>
            <p className="text-xs text-white/40">Your information is treated confidentially.</p>
          </motion.div>
        </div>
      </section>
    </main>
  );
}
