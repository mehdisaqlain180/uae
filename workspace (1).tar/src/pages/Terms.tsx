import { PageHero, Breadcrumbs } from '../components/PageComponents';
import { config } from '../config';

export default function TermsPage() {
  return (
    <main>
      <PageHero
        eyebrow="Legal"
        title="Terms & Conditions"
        subtitle="Terms governing the use of our website and services."
      />
      <Breadcrumbs items={[{ label: 'Terms & Conditions' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-sm max-w-none">
            <p className="text-sm text-gray-muted mb-8">Last updated: January 2026</p>

            <div className="space-y-8">
              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">1. About These Terms</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  These terms and conditions govern your use of the {config.business.name} website and services. By using our website or engaging our services, you agree to these terms.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">2. Our Services</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  We provide consultancy guidance on UAE residency, Golden Visa and business setup matters. Our services include eligibility assessment, documentation guidance and application support. We are a private consultancy and are not affiliated with any government authority.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">3. No Guarantee of Outcomes</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  We do not guarantee visa approval, residency grants or any specific outcome. All decisions regarding residency applications are made by the relevant UAE authorities. We provide professional guidance and support, but outcomes depend on individual eligibility and authority decisions.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">4. Accuracy of Information</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  While we strive to provide accurate and up-to-date information, UAE regulations and requirements may change. Information on this website is provided as general guidance and should not be relied upon as definitive legal advice. We recommend confirming current requirements during a consultation.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">5. Your Responsibilities</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  You are responsible for providing accurate and complete information. You must ensure that any documents or information submitted through our services are genuine and truthful.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">6. Intellectual Property</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  All content on this website, including text, images and design, is the property of {config.legal.companyName} and is protected by applicable intellectual property laws.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">7. Limitation of Liability</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  To the fullest extent permitted by law, we shall not be liable for any indirect, incidental or consequential losses arising from your use of our website or services.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">8. Governing Law</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  These terms are governed by the laws applicable in the UAE. Any disputes shall be subject to the jurisdiction of the courts of Dubai, UAE.
                </p>
              </div>

              <div>
                <h2 className="font-heading font-semibold text-lg text-navy mb-3">9. Contact</h2>
                <p className="text-sm text-gray-muted leading-relaxed">
                  For questions about these terms, please contact us at{' '}
                  <a href={`mailto:${config.contact.email}`} className="text-gold hover:underline">{config.contact.email}</a>.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
