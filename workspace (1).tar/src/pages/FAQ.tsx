import { PageHero, Breadcrumbs, CTASection } from '../components/PageComponents';
import { faqs } from '../data';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function FAQPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <main>
      <PageHero
        eyebrow="FAQ"
        title="Frequently Asked Questions"
        subtitle="Answers to common questions about UAE Golden Visa, residency and our consultancy services."
      />
      <Breadcrumbs items={[{ label: 'FAQ' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="space-y-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            {faqs.map((faq, index) => (
              <motion.div 
                key={index} 
                className="border border-gray-100 rounded-lg overflow-hidden"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              >
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full flex items-center justify-between p-5 text-left hover:bg-ivory/50 transition-colors"
                  aria-expanded={openFaq === index}
                >
                  <span className="font-heading font-medium text-sm sm:text-base text-navy pr-4">{faq.question}</span>
                  {openFaq === index ? (
                    <ChevronUp size={18} className="text-gold shrink-0" />
                  ) : (
                    <ChevronDown size={18} className="text-gray-muted shrink-0" />
                  )}
                </button>
                <div className={`accordion-content ${openFaq === index ? 'open' : ''}`}>
                  <div className="px-5 pb-5">
                    <p className="text-sm text-gray-muted leading-relaxed">{faq.answer}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div 
            className="mt-10 p-6 bg-ivory rounded-lg border border-gray-100"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <p className="text-sm text-gray-muted leading-relaxed mb-4">
              <strong className="text-navy">Important:</strong> Requirements and eligibility can change. Final eligibility is determined under applicable UAE regulations and by the relevant authorities. The information provided here is general guidance only.
            </p>
            <p className="text-sm text-gray-muted">
              If you have a specific question about your situation, we recommend booking a consultation for personalised guidance.
            </p>
          </motion.div>

          <motion.div 
            className="mt-8 text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <p className="text-sm text-gray-muted mb-4">Still have questions?</p>
            <Link
              to="/contact"
              className="btn-primary inline-flex items-center gap-2 bg-gold text-navy px-6 py-3 rounded font-semibold text-sm"
            >
              Get in Touch
            </Link>
          </motion.div>
        </div>
      </section>

      <CTASection />
    </main>
  );
}
