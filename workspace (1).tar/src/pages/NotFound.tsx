import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { images } from '../images';

export default function NotFoundPage() {
  return (
    <main className="min-h-screen relative flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={images.dubai3}
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-navy/85 backdrop-blur-sm" />
      </div>

      <motion.div 
        className="relative text-center px-4 z-10"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <div className="mb-8">
          <div className="w-24 h-24 mx-auto rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center mb-6">
            <span className="font-heading font-bold text-3xl text-gold">404</span>
          </div>
          <h1 className="font-heading font-bold text-4xl text-white mb-3">Page not found.</h1>
          <p className="text-white/60 max-w-md mx-auto">
            The page you're looking for may have moved or no longer exists.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            to="/"
            className="btn-primary bg-gold text-navy px-6 py-3 rounded font-semibold text-sm"
          >
            Back to Home
          </Link>
          <Link
            to="/contact"
            className="border border-white/30 text-white px-6 py-3 rounded font-medium text-sm hover:bg-white/10 transition-all duration-300"
          >
            Contact Us
          </Link>
        </div>
      </motion.div>
    </main>
  );
}
