import { PageHero, Breadcrumbs, CTASection } from '../components/PageComponents';
import { processSteps } from '../data';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function ProcessPage() {
  return (
    <main>
      <PageHero
        eyebrow="Our Process"
        title="A clear process, handled properly"
        subtitle="From initial consultation to application follow-up, we guide you through each stage with clarity and attention to detail."
      />
      <Breadcrumbs items={[{ label: 'Process' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <div className="space-y-0">
              {processSteps.map((step, index) => (
                <div key={step.number} className="relative flex gap-6 pb-10 last:pb-0">
                  {/* Vertical line */}
                  {index < processSteps.length - 1 && (
                    <div className="absolute left-6 top-14 bottom-0 w-px bg-gold/20" />
                  )}
                  <div className="shrink-0 w-12 h-12 rounded-full border-2 border-gold flex items-center justify-center bg-white z-10">
                    <span className="font-heading font-bold text-sm text-gold">{step.number}</span>
                  </div>
                  <div className="pt-1">
                    <h3 className="font-heading font-semibold text-xl text-navy mb-2">{step.title}</h3>
                    <p className="text-gray-muted leading-relaxed">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-20 bg-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-heading font-bold text-2xl text-navy mb-4">What to expect</h2>
            <p className="text-gray-muted leading-relaxed mb-6">
              Every client's situation is different, and timelines vary depending on the pathway and individual circumstances. What remains consistent is our commitment to clear communication, professional handling and attention to your specific requirements.
            </p>
            <p className="text-gray-muted leading-relaxed mb-8">
              We don't make promises about outcomes or processing times — these are determined by the relevant UAE authorities. What we do promise is transparent guidance and dedicated support throughout the process.
            </p>
            <Link
              to="/contact"
              className="btn-primary inline-flex items-center gap-2 bg-gold text-navy px-6 py-3 rounded font-semibold text-sm"
            >
              Start with a Consultation <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      <CTASection />
    </main>
  );
}
