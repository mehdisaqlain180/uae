import { PageHero, Breadcrumbs, CTASection, FeatureList, Disclaimer } from '../components/PageComponents';
import { services } from '../data';
import { images } from '../images';
import { Link } from 'react-router-dom';
import { ArrowRight, Building, TrendingUp, Lightbulb, Briefcase, GraduationCap, Award } from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  building: <Building size={24} />,
  'trending-up': <TrendingUp size={24} />,
  lightbulb: <Lightbulb size={24} />,
  briefcase: <Briefcase size={24} />,
  'graduation-cap': <GraduationCap size={24} />,
  award: <Award size={24} />,
};

export default function GoldenVisaPage() {
  return (
    <main>
      <PageHero
        eyebrow="UAE Residency Programme"
        title="UAE Golden Visa"
        subtitle="Long-term residency for investors, professionals, entrepreneurs and talented individuals. Subject to eligibility and applicable UAE regulations."
      />
      <Breadcrumbs items={[{ label: 'Golden Visa' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <div className="gold-line mb-4" />
              <h2 className="font-heading font-bold text-2xl text-navy mb-4">Understanding the Programme</h2>
              <p className="text-gray-muted leading-relaxed mb-6">
                The UAE Golden Visa is a long-term residency programme that offers eligible individuals the opportunity to live, work and study in the UAE without the need for a standard employer sponsor. The programme covers multiple categories, each with specific eligibility requirements.
              </p>
              <p className="text-gray-muted leading-relaxed mb-6">
                Whether you're an investor, property owner, entrepreneur, skilled professional or individual with specialised talents, there may be a pathway that suits your circumstances. We help you understand which category may be relevant and guide you through the process.
              </p>
              <FeatureList items={[
                'Long-term residency (typically 5 or 10 years, renewable)',
                'Family sponsorship options',
                'Flexibility to live and work in the UAE',
                'Multiple entry and exit without time restrictions',
                'Professional guidance throughout the process',
              ]} />
              <Disclaimer />
            </div>
            <div>
              <h3 className="font-heading font-semibold text-lg text-navy mb-6">Residency Pathways</h3>
              <div className="space-y-4">
                {services.map((service) => (
                  <Link
                    key={service.id}
                    to={service.path}
                    className="card-hover flex items-start gap-4 p-5 border border-gray-100 rounded-lg hover:border-gold/40 group"
                  >
                    <div className="text-gold shrink-0 mt-0.5">{iconMap[service.icon]}</div>
                    <div className="flex-1">
                      <h4 className="font-heading font-semibold text-navy group-hover:text-gold transition-colors mb-1">
                        {service.title}
                      </h4>
                      <p className="text-sm text-gray-muted">{service.shortDescription}</p>
                    </div>
                    <ArrowRight size={16} className="text-gray-muted group-hover:text-gold transition-colors shrink-0 mt-1" />
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-20 bg-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="overflow-hidden rounded-lg">
              <img
                src={images.goldenVisa}
                alt="Professional business environment in the UAE"
                className="w-full h-[350px] object-cover img-hover"
                loading="lazy"
              />
            </div>
            <div>
              <h2 className="font-heading font-bold text-2xl text-navy mb-4">Who might be eligible?</h2>
              <p className="text-gray-muted leading-relaxed mb-6">
                Eligibility depends on the specific pathway and individual circumstances. Common categories include property investors, business investors, entrepreneurs, skilled professionals in priority fields, outstanding students and individuals with recognised specialised talents.
              </p>
              <p className="text-gray-muted leading-relaxed mb-6">
                Requirements and thresholds are set by the relevant UAE authorities and may be updated. We recommend discussing your specific situation during a consultation to understand which pathway may be most relevant.
              </p>
              <Link to="/contact" className="btn-primary inline-flex items-center gap-2 bg-gold text-navy px-6 py-3 rounded font-semibold text-sm">
                Check Your Eligibility <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <CTASection />
    </main>
  );
}
