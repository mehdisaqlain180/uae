import { PageHero, Breadcrumbs, CTASection } from '../components/PageComponents';
import { images } from '../images';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

export default function AboutPage() {
  return (
    <main>
      <PageHero
        eyebrow="About Us"
        title="Professional UAE Residency Consultancy"
        subtitle="We provide focused guidance on UAE Golden Visa, residency and business setup for international clients."
      />
      <Breadcrumbs items={[{ label: 'About' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <div className="gold-line mb-4" />
              <h2 className="font-heading font-bold text-2xl text-navy mb-4">Who we are</h2>
              <p className="text-gray-muted leading-relaxed mb-6">
                We are a UAE-focused consultancy specialising in residency and immigration guidance. Our team works with international investors, professionals, entrepreneurs and families who are looking to establish themselves in the UAE.
              </p>
              <p className="text-gray-muted leading-relaxed mb-6">
                Our approach is straightforward: we take time to understand your situation, identify the most relevant options and guide you through the process with clarity and attention to detail. We don't make promises about outcomes — we provide professional support and clear communication throughout.
              </p>
              <p className="text-gray-muted leading-relaxed">
                Every client's circumstances are different. We treat each enquiry with appropriate discretion and provide personalised guidance based on your specific situation and goals.
              </p>
            </motion.div>
            <motion.div 
              className="overflow-hidden rounded-lg shadow-xl"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <img
                src={images.about}
                alt="Professional consultant in a modern office environment"
                className="w-full h-[400px] object-cover img-hover"
                loading="lazy"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-20 bg-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h2 
            className="font-heading font-bold text-2xl text-navy mb-10 text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Our approach
          </motion.h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: 'Clarity', desc: 'We explain requirements and processes in straightforward terms, avoiding unnecessary complexity.' },
              { title: 'Confidentiality', desc: 'Your information and circumstances are handled with appropriate discretion at all times.' },
              { title: 'Compliance', desc: 'We work within the framework of applicable UAE regulations and requirements.' },
              { title: 'Care', desc: 'We take time to understand your individual situation and provide personalised guidance.' },
            ].map((item, index) => (
              <motion.div 
                key={item.title} 
                className="bg-white p-6 rounded-lg border border-gray-100 card-hover"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <h3 className="font-heading font-semibold text-navy mb-2">{item.title}</h3>
                <p className="text-sm text-gray-muted leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-heading font-bold text-2xl text-navy mb-6">What we do — and don't do</h2>
            <div className="grid sm:grid-cols-2 gap-8 text-left">
              <div>
                <h3 className="font-heading font-semibold text-navy mb-3">We provide</h3>
                <ul className="space-y-2">
                  {[
                    'Residency pathway guidance',
                    'Eligibility assessment',
                    'Documentation support',
                    'Application process guidance',
                    'Business setup advice',
                    'Clear communication throughout',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm text-gray-muted">
                      <Check size={14} className="text-gold shrink-0 mt-0.5" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-heading font-semibold text-navy mb-3">We don't</h3>
                <ul className="space-y-2">
                  {[
                    'Guarantee visa approval',
                    'Make decisions on behalf of authorities',
                    'Provide legal representation in court',
                    'Offer immigration advice outside UAE scope',
                    'Make promises about processing times',
                    'Claim government affiliation',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm text-gray-muted">
                      <span className="text-gray-muted shrink-0 mt-0.5">—</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <CTASection />
    </main>
  );
}
