import { PageHero, Breadcrumbs } from '../components/PageComponents';
import ConsultationForm from '../components/ConsultationForm';
import { config } from '../config';
import { motion } from 'framer-motion';
import { Mail, MapPin, Clock } from 'lucide-react';
import WhatsAppIcon from '../components/WhatsAppIcon';

export default function ContactPage() {
  return (
    <main>
      <PageHero
        eyebrow="Contact"
        title="Start with a conversation"
        subtitle="Tell us about your requirements and we'll help you understand the most relevant next steps."
      />
      <Breadcrumbs items={[{ label: 'Contact' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
            {/* Form */}
            <motion.div 
              className="lg:col-span-3"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="font-heading font-bold text-2xl text-navy mb-2">Request a Consultation</h2>
              <p className="text-gray-muted text-sm mb-8">
                Complete the form below and our team will be in touch. All enquiries are treated confidentially.
              </p>
              <ConsultationForm />
            </motion.div>

            {/* Contact Info */}
            <motion.div 
              className="lg:col-span-2"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <div className="bg-ivory rounded-lg p-6 lg:p-8 border border-gray-100 sticky top-28">
                <h3 className="font-heading font-semibold text-lg text-navy mb-6">Contact Details</h3>

                <div className="space-y-5">
                  <div className="flex items-start gap-3">
                    <Mail size={18} className="text-gold shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-navy mb-0.5">Email</p>
                      <a href={`mailto:${config.contact.email}`} className="text-sm text-gray-muted hover:text-gold transition-colors">
                        {config.contact.email}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <WhatsAppIcon size={18} className="text-gold shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-navy mb-0.5">WhatsApp</p>
                      <a
                        href={config.contact.whatsappLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-gray-muted hover:text-gold transition-colors"
                      >
                        Chat on WhatsApp
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <MapPin size={18} className="text-gold shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-navy mb-0.5">Office</p>
                      <p className="text-sm text-gray-muted">
                        {config.contact.address.line1}<br />
                        {config.contact.address.line2}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock size={18} className="text-gold shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-navy mb-0.5">Business Hours</p>
                      <p className="text-sm text-gray-muted">
                        {config.contact.hours.weekday}<br />
                        {config.contact.hours.weekend}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-gray-200">
                  <p className="text-xs text-gray-muted leading-relaxed">
                    Your information is treated confidentially. We do not share your details with third parties without your consent.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </main>
  );
}
