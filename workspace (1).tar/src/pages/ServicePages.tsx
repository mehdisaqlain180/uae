import { ServicePageTemplate } from '../components/PageComponents';
import { PageHero, Breadcrumbs, CTASection, FeatureList, Disclaimer } from '../components/PageComponents';
import { images } from '../images';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export function ResidencyPage() {
  return (
    <main>
      <PageHero
        eyebrow="UAE Residency"
        title="UAE Residency Options"
        subtitle="Explore the different residency pathways available in the UAE. Each option has specific eligibility requirements set by the relevant authorities."
      />
      <Breadcrumbs items={[{ label: 'Residency' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <div className="gold-line mb-4" />
            <h2 className="font-heading font-bold text-2xl text-navy mb-4">Understanding Your Options</h2>
            <p className="text-gray-muted leading-relaxed mb-6">
              The UAE offers several residency pathways for international individuals and families. The most appropriate option depends on your circumstances, qualifications, investment capacity and personal goals.
            </p>
            <p className="text-gray-muted leading-relaxed mb-8">
              We help you understand which pathway may be most relevant and guide you through the requirements and process. All eligibility is subject to current UAE regulations and decisions by the relevant authorities.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-8">
            {[
              { title: 'Golden Visa', desc: 'Long-term residency for qualifying investors, professionals and talented individuals.', path: '/golden-visa' },
              { title: 'Investor Visa', desc: 'For business investors making qualifying investments in the UAE economy.', path: '/investor-visa' },
              { title: 'Property Investor', desc: 'Residency through qualifying property investment in the UAE.', path: '/property-investor' },
              { title: 'Entrepreneur Visa', desc: 'For founders establishing businesses and ventures in the UAE.', path: '/entrepreneur-visa' },
              { title: 'Skilled Professional', desc: 'For qualified professionals working in priority sectors.', path: '/skilled-professional' },
              { title: 'Family Residency', desc: 'Including family members in your UAE residency arrangements.', path: '/family-residency' },
            ].map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className="card-hover group border border-gray-100 rounded-lg p-6 hover:border-gold/40"
              >
                <h3 className="font-heading font-semibold text-navy mb-2 group-hover:text-gold transition-colors">{item.title}</h3>
                <p className="text-sm text-gray-muted mb-3">{item.desc}</p>
                <span className="text-sm font-medium text-navy flex items-center gap-1 group-hover:text-gold transition-colors">
                  Learn more <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
                </span>
              </Link>
            ))}
          </div>
          <Disclaimer />
        </div>
      </section>

      <CTASection />
    </main>
  );
}

export function InvestorVisaPage() {
  return (
    <ServicePageTemplate
      title="Investor Visa"
      description="The investor visa pathway is designed for individuals making qualifying investments in the UAE. This includes business investments and capital contributions that support economic development in the Emirates. Eligibility is subject to applicable UAE regulations."
      features={[
        'Qualifying business investment in the UAE',
        'Long-term residency option',
        'Family sponsorship pathways',
        'Contribution to UAE economic development',
        'Professional guidance through the process',
      ]}
      additionalInfo="Investment requirements and thresholds are determined by the relevant UAE authorities and may be updated. We recommend discussing your specific investment plans during a consultation."
      image={images.investor}
    />
  );
}

export function PropertyInvestorPage() {
  return (
    <ServicePageTemplate
      title="Property Investor Visa"
      description="For those investing in UAE real estate, the property investor pathway offers a route to long-term residency. Specific requirements regarding property type, value and ownership apply, subject to current UAE regulations."
      features={[
        'Qualifying property investment in the UAE',
        'Long-term residency for property owners',
        'Family inclusion options',
        'Various property types may qualify',
        'Professional guidance on requirements',
      ]}
      additionalInfo="Property investment thresholds and qualifying property types are set by the relevant authorities. Requirements may vary and can be updated. We can review your specific property investment against current criteria."
      image={images.property}
    />
  );
}

export function EntrepreneurVisaPage() {
  return (
    <ServicePageTemplate
      title="Entrepreneur Visa"
      description="The entrepreneur pathway supports individuals establishing businesses and ventures in the UAE. This option is designed for founders and business owners who contribute to innovation and economic growth in the Emirates."
      features={[
        'Business establishment in the UAE',
        'Startup and venture-friendly pathway',
        'Residency for business founders',
        'Support for innovation and growth',
        'Guidance on business and residency requirements',
      ]}
      additionalInfo="Entrepreneur visa requirements may include specific business plan criteria, company registration and other conditions set by the relevant authorities."
      image={images.entrepreneur}
    />
  );
}

export function SkilledProfessionalPage() {
  return (
    <ServicePageTemplate
      title="Skilled Professional Visa"
      description="Skilled professionals in designated fields and priority occupations may be eligible for long-term UAE residency. This pathway recognises professional expertise and contribution across various sectors of the UAE economy."
      features={[
        'Professional qualification-based eligibility',
        'Priority occupation categories',
        'Executive and specialist positions',
        'Long-term residency option',
        'Assessment of professional credentials',
      ]}
      additionalInfo="Eligible professions and qualification requirements are defined by the relevant UAE authorities. Criteria may include specific education levels, salary thresholds and professional experience."
      image={images.professional}
    />
  );
}

export function FamilyResidencyPage() {
  return (
    <main>
      <PageHero
        eyebrow="Family Residency"
        title="Family Residency in the UAE"
        subtitle="Including your family in your UAE residency arrangements. The Golden Visa programme generally provides for family sponsorship, subject to applicable regulations."
      />
      <Breadcrumbs items={[{ label: 'Family Residency' }]} />

      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <div className="gold-line mb-4" />
              <h2 className="font-heading font-bold text-2xl text-navy mb-4">Bringing Your Family</h2>
              <p className="text-gray-muted leading-relaxed mb-6">
                One of the benefits of UAE long-term residency is the ability to sponsor family members. The specific provisions regarding who can be included and the requirements for family sponsorship are determined under applicable UAE regulations.
              </p>
              <p className="text-gray-muted leading-relaxed mb-6">
                We help you understand the family sponsorship options available alongside your residency pathway and guide you through the relevant documentation and process.
              </p>
              <FeatureList items={[
                'Family sponsorship guidance',
                'Spouse and children inclusion',
                'Documentation preparation',
                'Coordinated application process',
                'Ongoing support for family matters',
              ]} />
              <Disclaimer />
            </div>
            <div className="overflow-hidden rounded-lg">
              <img
                src={images.family}
                alt="Family enjoying life in the UAE"
                className="w-full h-[400px] lg:h-full object-cover"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <CTASection />
    </main>
  );
}
