import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import ScrollProgress from './components/ScrollProgress';
import CookieBanner from './components/CookieBanner';
import { BackToTop } from './components/UXComponents';
import Home from './pages/Home';
import GoldenVisa from './pages/GoldenVisa';
import { ResidencyPage, InvestorVisaPage, PropertyInvestorPage, EntrepreneurVisaPage, SkilledProfessionalPage, FamilyResidencyPage } from './pages/ServicePages';
import BusinessSetup from './pages/BusinessSetup';
import About from './pages/About';
import Process from './pages/Process';
import FAQ from './pages/FAQ';
import Contact from './pages/Contact';
import PrivacyPolicy from './pages/PrivacyPolicy';
import Terms from './pages/Terms';
import NotFound from './pages/NotFound';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function AppLayout() {
  return (
    <>
      <ScrollProgress />
      <ScrollToTop />
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/golden-visa" element={<GoldenVisa />} />
        <Route path="/residency" element={<ResidencyPage />} />
        <Route path="/investor-visa" element={<InvestorVisaPage />} />
        <Route path="/property-investor" element={<PropertyInvestorPage />} />
        <Route path="/entrepreneur-visa" element={<EntrepreneurVisaPage />} />
        <Route path="/skilled-professional" element={<SkilledProfessionalPage />} />
        <Route path="/family-residency" element={<FamilyResidencyPage />} />
        <Route path="/business-setup" element={<BusinessSetup />} />
        <Route path="/about" element={<About />} />
        <Route path="/process" element={<Process />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Footer />
      <WhatsAppButton />
      <BackToTop />
      <CookieBanner />
    </>
  );
}

export default function App() {
  return (
    <HashRouter>
      <AppLayout />
    </HashRouter>
  );
}
