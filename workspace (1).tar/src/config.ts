// Central configuration file - update these values for the client
export const config = {
  business: {
    name: 'Golden Visa UAE',
    tagline: 'UAE Residency & Investment Consultancy',
    description: 'Expert guidance for UAE Golden Visa, residency, property investment and business setup.',
    url: 'https://www.goldenvisauae.net',
  },
  contact: {
    email: 'info@goldenvisauae.net',
    phone: '+971 XX XXX XXXX',
    whatsapp: '+971XXXXXXXXX', // Replace with actual WhatsApp number
    whatsappLink: 'https://wa.me/971XXXXXXXXX', // Replace with actual number (no + or spaces)
    address: {
      line1: 'Business Bay',
      line2: 'Dubai, United Arab Emirates',
      city: 'Dubai',
      country: 'UAE',
    },
    hours: {
      weekday: 'Sunday – Thursday: 9:00 AM – 6:00 PM',
      weekend: 'Saturday: By appointment',
    },
  },
  social: {
    linkedin: '',
    instagram: '',
    twitter: '',
  },
  analytics: {
    googleAnalyticsId: '', // Add GA4 ID when available
    googleTagManagerId: '', // Add GTM ID when available
    metaPixelId: '', // Add Meta Pixel ID when available
  },
  legal: {
    companyName: 'Golden Visa UAE',
    year: 2026,
  },
};
